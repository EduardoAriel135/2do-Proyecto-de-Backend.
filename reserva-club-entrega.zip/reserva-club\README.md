# API de Reservas de Club Deportivo

API REST para gestionar deportes, canchas, socios, reservas y bloqueos de
mantenimiento de un club deportivo. Implementa el contrato `swagger.yaml` sobre
Flask y MySQL.

## Integrantes

Completar antes de entregar:

| Integrante | Legajo | Correo |
| --- | --- | --- |
| Nombre y apellido | | |
| Nombre y apellido | | |

## Requisitos

- Python 3.11 o superior (probado con 3.14)
- MySQL 8.0 o superior

Versiones exactas de las dependencias en `requirements.txt`:

| Paquete | Versión |
| --- | --- |
| Flask | 3.1.3 |
| PyMySQL | 1.1.2 |
| python-dotenv | 1.2.1 |
| cryptography | 46.0.5 |
| pytest | 9.0.2 |
| PyYAML | 6.0.3 |

## Instalación

```bash
python -m venv .venv
```

Activar el entorno virtual:

```bash
# Linux / macOS
source .venv/bin/activate

# Windows PowerShell
.venv\Scripts\Activate.ps1
```

Instalar las dependencias:

```bash
pip install -r requirements.txt
```

Configurar las variables de entorno:

```bash
# Linux / macOS
cp .env.example .env

# Windows PowerShell
Copy-Item .env.example .env
```

Editar `.env` con las credenciales reales de MySQL. El archivo está en
`.gitignore` y no debe publicarse.

## Creación de la base de datos

```bash
mysql -u root -p < sql/init_db.sql
```

Opcionalmente, cargar datos ficticios:

```bash
mysql -u root -p club_deportivo < sql/datos_ficticios.sql
```

### Nota sobre SQLite

MySQL es el motor por defecto. Para probar la API en local sin instalar un
servidor se puede usar SQLite, aplicando antes el esquema equivalente de
`tests/esquema_sqlite.sql` (`sql/init_db.sql` es DDL exclusivo de MySQL, con
`ENGINE = InnoDB` y `COLLATE utf8mb4_0900_ai_ci`, y SQLite no lo entiende):

```bash
DB_ENGINE=sqlite DB_SQLITE_PATH=instance/club.sqlite3 python -c "import sqlite3, pathlib; c = sqlite3.connect('instance/club.sqlite3'); c.executescript(pathlib.Path('tests/esquema_sqlite.sql').read_text(encoding='utf-8')); c.commit(); c.close()"
```

Si se arranca contra un archivo SQLite sin esquema, los endpoints que consultan
la base responden `500` con `no such table`. Los endpoints de diagnóstico `/` y
`/salud` funcionan igual, porque no tocan la base.

## Ejecución

```bash
python app.py
```

La API queda disponible en `http://127.0.0.1:5000`.

Endpoints de diagnóstico:

```bash
curl http://127.0.0.1:5000/
curl http://127.0.0.1:5000/salud
```

## Tests

La suite corre contra SQLite en un archivo temporal, así que no hace falta
levantar MySQL para probar:

```bash
pytest tests/ -q
```

Los tests de `tests/test_contrato.py` leen `swagger.yaml` y verifican que el
contrato y la implementación devuelvan los mismos códigos de estado. Si se
cambia un endpoint, hay que actualizar el contrato en el mismo cambio.

## Estructura del proyecto

```
reserva-club/
├── app.py                  Punto de entrada
├── swagger.yaml            Contrato OpenAPI
├── requirements.txt
├── .env.example
├── sql/
│   ├── init_db.sql         Esquema de MySQL
│   └── datos_ficticios.sql Datos de prueba
├── src/
│   ├── __init__.py         Fábrica de la aplicación Flask
│   ├── config.py           Configuración y constantes de negocio
│   ├── db.py               Conexión, transacciones y adaptadores
│   ├── errors.py           Errores de la aplicación
│   ├── http.py             Utilidades de request y response
│   ├── time_utils.py       Manejo de GMT-3 y reglas temporales
│   ├── routes/             Blueprints HTTP
│   ├── services/           Reglas de negocio
│   └── repos/              Acceso a datos
└── tests/
```

La separación sigue el orden en que atraviesa una petición: `routes` valida y
traduce HTTP, `services` aplica las reglas de negocio y `repos` habla con la
base de datos. Solo los repositorios escriben SQL.

## Reglas de negocio

- El club atiende todos los días de 08:00 a 23:00.
- Las reservas duran de 1 a 3 horas, en punto, dentro del mismo día.
- El desplazamiento horario es fijo GMT-3 (`-03:00`) y no se convierte entre
  zonas horarias.
- No puede superponerse ni la cancha ni el socio.
- Al crear una reserva se guarda la tarifa vigente y se calcula el total en el
  servidor.
- Estados: `confirmada`, `cancelada`, `finalizada`. Cancelar solo es posible
  antes del inicio; finalizar, una vez alcanzado el horario de fin.
- Repetir el estado actual devuelve éxito sin modificar la reserva.

## Paginación y HATEOAS

Los listados aceptan `_limit` (1 a 100, por defecto 10) y `_offset` (por
defecto 0). Los filtros se aplican **antes** de paginar.

Cada listado incluye los enlaces `_first`, `_prev`, `_next` y `_last`. En la
primera página `_prev` es `null` y en la última `_next` es `null`. Los enlaces
conservan los filtros aplicados.

Un listado sin resultados responde `200` con el arreglo vacío, nunca `204`.

## Extensiones opcionales

### Bloqueos de mantenimiento

`POST /bloqueos` impide reservar en un intervalo. Se considera en la consulta de
`GET /canchas/disponibles` y `DELETE /bloqueos/{id}` libera la restricción sin
tocar las reservas existentes. A diferencia de una reserva, el bloqueo puede
ocupar toda la jornada.

### Reservas recurrentes

`POST /reservas/recurrentes` crea una serie semanal para la misma cancha, el
mismo socio y el mismo horario. `cantidad_semanas` va de 2 a 12 e incluye la
primera.

La serie es **atómica**: si una sola fecha está ocupada, no se guarda ninguna
reserva y se responde `409` con el listado de fechas en conflicto.

## Ejemplos

Crear un socio:

```bash
curl -X POST http://127.0.0.1:5000/socios \
  -H "Content-Type: application/json" \
  -d '{"nombre": "Ana Gomez", "email": "ana@example.com"}'
```

Crear una cancha:

```bash
curl -X POST http://127.0.0.1:5000/canchas \
  -H "Content-Type: application/json" \
  -d '{"nombre": "Cancha 1 - Futbol 5", "id_deporte": 1, "precio_hora": 10000, "techada": true}'
```

Consultar disponibilidad:

```bash
curl "http://127.0.0.1:5000/canchas/disponibles?fecha=2026-10-15&hora_inicio=18:00:00&hora_fin=20:00:00"
```

Crear una reserva:

```bash
curl -X POST http://127.0.0.1:5000/reservas \
  -H "Content-Type: application/json" \
  -d '{"id_socio": 1, "id_cancha": 1, "fecha_hora_inicio": "2026-10-15T18:00:00.000000-03:00", "fecha_hora_fin": "2026-10-15T20:00:00.000000-03:00"}'
```

Cambiar el estado de una reserva:

```bash
curl -X PUT http://127.0.0.1:5000/reservas/1/estado \
  -H "Content-Type: application/json" \
  -d '{"estado": "cancelada"}'
```

## Formato de errores

Todos los errores usan la misma estructura:

```json
{
  "errors": [
    {
      "code": "ERROR_VALIDACION",
      "message": "El intervalo de la reserva es invalido",
      "level": "error",
      "description": "La duracion debe ser de 1 a 3 horas"
    }
  ]
}
```

El conflicto de una serie de reservas agrega las fechas en conflicto:

```json
{
  "errors": [ ... ],
  "conflictos": ["2026-10-22", "2026-11-05"]
}
```

## Notas sobre el enunciado

- La consulta de disponibilidad admite fechas pasadas: el enunciado no exige que
  la fecha consultada sea futura, solo que las reservas nuevas no empiecen en el
  pasado. Si se prefiere restringirla, el cambio está en
  `src/repos/canchas_repo.py`.
- El enunciado pide MySQL "preferentemente". MySQL es el motor por defecto;
  SQLite queda solo para correr los tests sin servidor.
