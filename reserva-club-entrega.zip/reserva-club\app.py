"""Punto de entrada: expone la instancia WSGI en el modulo como `app`."""

import os

from dotenv import load_dotenv

from src import crear_app

load_dotenv()

app = crear_app()


if __name__ == "__main__":
    app.run(
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "5000")),
        debug=os.getenv("DEBUG", "0").strip().lower() in ("1", "true", "yes"),
    )
