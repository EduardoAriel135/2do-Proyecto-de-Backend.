-- Datos ficticios de prueba (MySQL 8.0+), sin informacion de personas reales.
-- Los ids se fijan explicitamente para que los ejemplos sean estables.
-- Ejecutar despues de sql/init_db.sql.

USE club_deportivo;

-- Fechas futuras para que la API acepte las reservas nuevas.
SET @futuro_f1 = DATE_ADD(CURDATE(), INTERVAL 30 DAY);
SET @futuro_f2 = DATE_ADD(CURDATE(), INTERVAL 45 DAY);
SET @futuro_f3 = DATE_ADD(CURDATE(), INTERVAL 60 DAY);

-- Todos activos salvo el ultimo, para probar el rechazo de inactivos y el filtro ?activo=false.
INSERT INTO socios (id, nombre, email, activo) VALUES
    (1, 'Ana Gomez',      'ana.gomez@example.com',      1),
    (2, 'Bruno Diaz',     'bruno.diaz@example.com',     1),
    (3, 'Carla Ruiz',     'carla.ruiz@example.com',     1),
    (4, 'Diego Sosa',     'diego.sosa@example.com',     1),
    (5, 'Elena Torres',   'elena.torres@example.com',   1),
    (6, 'Federico Paz',   'federico.paz@example.com',   1),
    (7, 'Gimena Acosta',  'gimena.acosta@example.com',  1),
    (8, 'Hernan Lopez',   'hernan.lopez@example.com',   0)
ON DUPLICATE KEY UPDATE
    nombre = VALUES(nombre),
    email  = VALUES(email),
    activo = VALUES(activo);

-- Cubre los tres deportes, techadas y no techadas, activas e inactivas.
INSERT INTO canchas (id, nombre, id_deporte, precio_hora, techada, activa) VALUES
    (1, 'Cancha 1 - Futbol 5',   1, 1000000, 0, 1),
    (2, 'Cancha 2 - Futbol 11',  1, 1500000, 0, 1),
    (3, 'Cancha 3 - Futbol 5',   1, 1000000, 1, 1),
    (4, 'Cancha 4 - Tenis',      2,  800000, 1, 1),
    (5, 'Cancha 5 - Tenis',      2,  800000, 0, 1),
    (6, 'Cancha 6 - Padel',      3,  900000, 1, 1),
    (7, 'Cancha 7 - Padel',      3,  900000, 1, 0)
ON DUPLICATE KEY UPDATE
    nombre      = VALUES(nombre),
    id_deporte  = VALUES(id_deporte),
    precio_hora = VALUES(precio_hora),
    techada     = VALUES(techada),
    activa      = VALUES(activa);

-- Tarifa historica: la Cancha 1 se sube mas abajo a 1200000, y estas reservas
-- deben conservar sus importes originales.
INSERT INTO reservas
    (id, id_socio, id_cancha, fecha_hora_inicio, fecha_hora_fin, estado, precio_hora, precio_total)
VALUES
    (1, 1, 1, CONCAT(@futuro_f1, ' 18:00:00.000000'), CONCAT(@futuro_f1, ' 20:00:00.000000'),
        'confirmada', 1000000, 2000000),
    (2, 3, 2, CONCAT(@futuro_f1, ' 20:00:00.000000'), CONCAT(@futuro_f1, ' 21:00:00.000000'),
        'confirmada', 1500000, 1500000),
    (3, 4, 1, CONCAT(@futuro_f2, ' 09:00:00.000000'), CONCAT(@futuro_f2, ' 12:00:00.000000'),
        'cancelada',  1000000, 3000000),
    -- Pasada, para probar que se lista aunque haya transcurrido.
    (4, 5, 4, CONCAT(DATE_SUB(CURDATE(), INTERVAL 10 DAY), ' 17:00:00.000000'),
                    CONCAT(DATE_SUB(CURDATE(), INTERVAL 10 DAY), ' 19:00:00.000000'),
        'finalizada',  800000, 1600000)
ON DUPLICATE KEY UPDATE
    estado = VALUES(estado);

-- Subida de tarifa para comprobar que los importes historicos no cambian.
UPDATE canchas SET precio_hora = 1200000 WHERE id = 1;

-- Bloqueo (extension opcional) de jornada completa sobre la Cancha 6.
INSERT INTO bloqueos (id, id_cancha, fecha, hora_inicio, hora_fin, motivo) VALUES
    (1, 6, @futuro_f3, '08:00:00', '23:00:00', 'Mantenimiento de iluminacion')
ON DUPLICATE KEY UPDATE motivo = VALUES(motivo);