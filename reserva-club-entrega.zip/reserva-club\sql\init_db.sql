-- Inicializacion MySQL 8.0+ del Club Deportivo: esquema completo y deportes precargados.
-- Los instantes se guardan como DATETIME(6) con la hora local del club (GMT-3 fijo),
-- nunca TIMESTAMP, para evitar conversiones implicitas de zona horaria.

CREATE DATABASE IF NOT EXISTS club_deportivo
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;

USE club_deportivo;

-- La hora local del club es GMT-3 fijo: 08:00 a 23:00, todos los dias.
-- Los CHECK repiten las reglas para que la base tampoco acepte datos invalidos.

-- Deportes: datos precargados, solo lectura para la API.
CREATE TABLE IF NOT EXISTS deportes (
    id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre  VARCHAR(50)  NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_deportes_nombre (nombre)
) ENGINE = InnoDB;

-- email normalizado por la API (minusculas, sin espacios). La unicidad tambien alcanza a los inactivos.
CREATE TABLE IF NOT EXISTS socios (
    id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre  VARCHAR(120) NOT NULL,
    email   VARCHAR(180) NOT NULL,
    activo  TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uq_socios_email (email),
    KEY idx_socios_nombre (nombre),
    KEY idx_socios_activo (activo)
) ENGINE = InnoDB;

-- Cada cancha pertenece a un unico deporte. precio_hora es un entero en centavos, mayor a cero.
CREATE TABLE IF NOT EXISTS canchas (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre       VARCHAR(120) NOT NULL,
    id_deporte   INT UNSIGNED NOT NULL,
    precio_hora  INT UNSIGNED NOT NULL,
    techada      TINYINT(1)   NOT NULL DEFAULT 0,
    activa       TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY idx_canchas_deporte (id_deporte),
    KEY idx_canchas_nombre (nombre),
    KEY idx_canchas_techada (techada),
    KEY idx_canchas_activa (activa),
    CONSTRAINT fk_canchas_deporte
        FOREIGN KEY (id_deporte) REFERENCES deportes (id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
    CONSTRAINT chk_canchas_precio CHECK (precio_hora > 0),
    CONSTRAINT chk_canchas_techada CHECK (techada IN (0, 1)),
    CONSTRAINT chk_canchas_activa  CHECK (activa  IN (0, 1))
) ENGINE = InnoDB;

-- precio_hora y precio_total son TARIFA HISTORICA: se copian al crear la reserva
-- y no se recalculan aunque luego cambie el precio de la cancha.
CREATE TABLE IF NOT EXISTS reservas (
    id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_socio          INT UNSIGNED NOT NULL,
    id_cancha         INT UNSIGNED NOT NULL,
    fecha_hora_inicio DATETIME(6)  NOT NULL,
    fecha_hora_fin    DATETIME(6)  NOT NULL,
    estado            VARCHAR(16)  NOT NULL DEFAULT 'confirmada',
    precio_hora       INT UNSIGNED NOT NULL,
    precio_total      INT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_reservas_cancha_estado (id_cancha, estado),
    KEY idx_reservas_socio_estado (id_socio, estado),
    KEY idx_reservas_inicio (fecha_hora_inicio),
    KEY idx_reservas_fin (fecha_hora_fin),
    KEY idx_reservas_cancha_inicio (id_cancha, fecha_hora_inicio, fecha_hora_fin),
    KEY idx_reservas_socio_inicio (id_socio, fecha_hora_inicio, fecha_hora_fin),
    CONSTRAINT fk_reservas_socio
        FOREIGN KEY (id_socio) REFERENCES socios (id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
    CONSTRAINT fk_reservas_cancha
        FOREIGN KEY (id_cancha) REFERENCES canchas (id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
    CONSTRAINT chk_reservas_estado
        CHECK (estado IN ('confirmada', 'cancelada', 'finalizada')),
    CONSTRAINT chk_reservas_intervalo
        CHECK (fecha_hora_inicio < fecha_hora_fin),
    CONSTRAINT chk_reservas_mismo_dia
        CHECK (DATE(fecha_hora_inicio) = DATE(fecha_hora_fin)),
    CONSTRAINT chk_reservas_horario
        CHECK (TIME(fecha_hora_inicio) >= '08:00:00'
           AND TIME(fecha_hora_fin)    <= '23:00:00'),
    CONSTRAINT chk_reservas_duracion CHECK (
        (TIMESTAMPDIFF(SECOND, fecha_hora_inicio, fecha_hora_fin) % 3600) = 0
        AND TIMESTAMPDIFF(SECOND, fecha_hora_inicio, fecha_hora_fin) BETWEEN 3600 AND 10800
    )
) ENGINE = InnoDB;

-- Bloqueos (extension opcional): impiden reservar y pesan en la disponibilidad.
-- Mismas horas en punto que una reserva, pero pueden durar mas de tres horas.
CREATE TABLE IF NOT EXISTS bloqueos (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_cancha    INT UNSIGNED NOT NULL,
    fecha        DATE         NOT NULL,
    hora_inicio  TIME         NOT NULL,
    hora_fin     TIME         NOT NULL,
    motivo       VARCHAR(200) NOT NULL,
    PRIMARY KEY (id),
    KEY idx_bloqueos_cancha_fecha (id_cancha, fecha),
    CONSTRAINT fk_bloqueos_cancha
        FOREIGN KEY (id_cancha) REFERENCES canchas (id)
        ON DELETE CASCADE
        ON UPDATE RESTRICT,
    CONSTRAINT chk_bloqueos_intervalo CHECK (hora_inicio < hora_fin),
    CONSTRAINT chk_bloqueos_horario CHECK (
        hora_inicio >= '08:00:00' AND hora_fin <= '23:00:00'
    )
) ENGINE = InnoDB;

-- Deportes precargados: se cargan una sola vez, no se administran por la API.
INSERT INTO deportes (nombre) VALUES
    ('Fútbol'),
    ('Tenis'),
    ('Pádel')
ON DUPLICATE KEY UPDATE nombre = VALUES(nombre);