"""Fabrica de la aplicacion Flask, para que las pruebas levanten una instancia aislada."""

from flask import Flask, jsonify

from . import config as configuracion
from .db import cerrar_conexion
from .http import registrar_manejadores
from .routes import (
    bloqueos,
    canchas,
    deportes,
    reservas,
    reservas_recurrentes,
    socios,
)


def crear_app(config=None):
    """Construye la aplicacion; `config` es una clase o un diccionario, y si se omite se usa DB_ENGINE."""
    app = Flask(__name__)
    app.config.from_object(config or configuracion.obtener_config())
    app.json.sort_keys = False

    # Una conexion por peticion, abierta al primer acceso.
    app.teardown_appcontext(cerrar_conexion)

    registrar_manejadores(app)

    app.register_blueprint(deportes.bp)
    app.register_blueprint(canchas.bp)
    app.register_blueprint(socios.bp)
    app.register_blueprint(reservas.bp)
    app.register_blueprint(reservas_recurrentes.bp)
    app.register_blueprint(bloqueos.bp)

    _registrar_salud(app)
    return app


def _registrar_salud(app):
    """Endpoint de verificacion, util para comprobar que el servicio levanta."""

    @app.get("/")
    def raiz():
        return jsonify(
            {
                "servicio": "API de Reservas de Club Deportivo",
                "documentacion": "swagger.yaml",
                "endpoint_salud": "/salud",
            }
        )

    @app.get("/salud")
    def salud():
        return jsonify({"estado": "ok"}), 200
