"""Configuracion de la aplicacion; los valores sensibles se leen del entorno o del .env."""

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

load_dotenv(BASE_DIR / ".env")

HORA_APERTURA = (8, 0, 0)
HORA_CIERRE = (23, 0, 0)

DURACION_MINIMA_HORAS = 1
DURACION_MAXIMA_HORAS = 3

# Offset fijo del club: GMT-3, sin horario de verano ni conversion.
UTC_OFFSET_HORAS = -3

ESTADO_CONFIRMADA = "confirmada"
ESTADO_CANCELADA = "cancelada"
ESTADO_FINALIZADA = "finalizada"
ESTADOS_RESERVA = (ESTADO_CONFIRMADA, ESTADO_CANCELADA, ESTADO_FINALIZADA)

PAGINA_LIMITE_PREDETERMINADO = 10
PAGINA_LIMITE_MINIMO = 1
PAGINA_LIMITE_MAXIMO = 100
PAGINA_OFFSET_PREDETERMINADO = 0


def _bool(nombre, predeterminado=False):
    """Lee un booleano del entorno aceptando solo true / false / 1 / 0."""
    crudo = os.getenv(nombre)
    if crudo is None:
        return predeterminado
    return crudo.strip().lower() in ("1", "true", "yes")


class Config:
    DEBUG = _bool("DEBUG", False)
    TESTING = False


class ConfigMySQL(Config):
    """MySQL, el motor de produccion que pide el enunciado."""

    DB_ENGINE = "mysql"
    DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
    DB_PORT = int(os.getenv("DB_PORT", "3306"))
    DB_USER = os.getenv("DB_USER", "")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_NAME = os.getenv("DB_NAME", "club_deportivo")


class ConfigSQLite(Config):
    """Perfil alternativo para correr los tests sin levantar MySQL; el SQL es el mismo."""

    DB_ENGINE = "sqlite"
    DB_SQLITE_PATH = os.getenv(
        "DB_SQLITE_PATH", str(BASE_DIR / "instance" / "club.sqlite3")
    )


def obtener_config(nombre=None):
    """Devuelve la clase de configuracion segun DB_ENGINE o el nombre pedido."""
    if nombre:
        mapa = {"mysql": ConfigMySQL, "sqlite": ConfigSQLite}
        if nombre not in mapa:
            raise ValueError(f"Configuracion desconocida: {nombre}")
        return mapa[nombre]

    motor = os.getenv("DB_ENGINE", "mysql").strip().lower()
    if motor == "sqlite":
        return ConfigSQLite
    return ConfigMySQL
