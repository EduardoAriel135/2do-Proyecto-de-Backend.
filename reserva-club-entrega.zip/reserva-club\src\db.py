"""Acceso a datos: MySQL por defecto, SQLite opcional para los tests, siempre parametrizado."""

import re
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, time
from pathlib import Path

from flask import current_app, g

from .errors import ErrorDeServidor

PATRON_PLACEHOLDER = re.compile(r"%s")

# Ancho fijo para que la comparacion lexicografica de los CHECK sea correcta.
FORMATO_INSTANTE = "%Y-%m-%d %H:%M:%S.%f"


def _configurar_sqlite():
    """Registra los adaptadores y convertores de fecha/hora, incluido el tipo `time`."""
    sqlite3.register_adapter(
        datetime, lambda valor: valor.strftime(FORMATO_INSTANTE)
    )
    sqlite3.register_adapter(date, lambda valor: valor.isoformat())
    sqlite3.register_adapter(time, lambda valor: valor.isoformat())

    # sqlite3 entrega los valores al convertidor como bytes.
    def _convertir(funcion):
        def envoltorio(valor):
            if isinstance(valor, (bytes, bytearray)):
                valor = valor.decode("utf-8")
            return funcion(valor)

        return envoltorio

    sqlite3.register_converter(
        "DATETIME", _convertir(lambda valor: datetime.fromisoformat(valor))
    )
    sqlite3.register_converter("DATE", _convertir(lambda valor: date.fromisoformat(valor)))
    sqlite3.register_converter("TIME", _convertir(lambda valor: time.fromisoformat(valor)))


_configurar_sqlite()


class Conexion:
    """Envoltura fina sobre la conexion del motor activo, para no depender del driver."""

    def __init__(self, cursor, motor):
        self._cursor = cursor
        self._motor = motor

    @property
    def motor(self):
        return self._motor

    @property
    def cursor(self):
        return self._cursor

    def ejecutar(self, sql, parametros=()):
        """Ejecuta una consulta parametrizada y devuelve el cursor."""
        consulta = self._adaptar(sql)
        self._cursor.execute(consulta, tuple(parametros))
        return self._cursor

    def obtener_filas(self, sql, parametros=()):
        """Devuelve todas las filas como lista de diccionarios."""
        cursor = self.ejecutar(sql, parametros)
        return [dict(fila) for fila in cursor.fetchall()]

    def obtener_fila(self, sql, parametros=()):
        """Devuelve la primera fila como diccionario, o None."""
        cursor = self.ejecutar(sql, parametros)
        fila = cursor.fetchone()
        return dict(fila) if fila is not None else None

    def obtener_valor(self, sql, parametros=(), por_defecto=None):
        """Devuelve el primer valor de la primera fila, o `por_defecto`."""
        fila = self.obtener_fila(sql, parametros)
        if not fila:
            return por_defecto
        valor = next(iter(fila.values()), None)
        return por_defecto if valor is None else valor

    def insertar(self, sql, parametros=()):
        """Ejecuta un INSERT y devuelve el id generado."""
        cursor = self.ejecutar(sql, parametros)
        return cursor.lastrowid

    def commit(self):
        self._cursor.connection.commit()

    def rollback(self):
        self._cursor.connection.rollback()

    def _adaptar(self, sql):
        """MySQL usa %s y SQLite usa ?, asi que se traduce el marcador."""
        if self._motor == "sqlite":
            return PATRON_PLACEHOLDER.sub("?", sql)
        return sql


def _abrir(config):
    """Abre una conexion fisica segun la configuracion activa."""
    if config["DB_ENGINE"] == "sqlite":
        ruta = Path(config["DB_SQLITE_PATH"])
        ruta.parent.mkdir(parents=True, exist_ok=True)
        _configurar_sqlite()
        conexion = sqlite3.connect(
            str(ruta),
            # Para que un DATETIME vuelva como datetime y no como texto.
            detect_types=sqlite3.PARSE_DECLTYPES,
            # Permite reutilizar la conexion entre peticiones del hilo.
            check_same_thread=False,
        )
        conexion.row_factory = sqlite3.Row
        conexion.execute("PRAGMA foreign_keys = ON")
        return conexion

    if not config.get("DB_USER") or not config.get("DB_NAME"):
        raise ErrorDeServidor(
            "Falta configurar la base de datos",
            description=(
                "Define DB_USER y DB_NAME en el archivo .env (ver .env.example) "
                "antes de iniciar la aplicacion con MySQL"
            ),
        )

    # Import perezoso: los tests pueden correr sobre SQLite sin el driver de MySQL.
    import pymysql

    return pymysql.connect(
        host=config["DB_HOST"],
        port=config["DB_PORT"],
        user=config["DB_USER"],
        password=config["DB_PASSWORD"],
        database=config["DB_NAME"],
        charset="utf8mb4",
        # El enunciado exige 6 digitos de fraccion de segundo en los instantes.
        # Autocommit queda desactivado: cada peticion controla su transaccion.
        autocommit=False,
        cursorclass=pymysql.cursors.DictCursor,
    )


def obtener_conexion():
    """Conexion de la peticion, cacheada en `flask.g` para compartir transaccion."""
    if "conexion" not in g:
        config = current_app.config
        fisica = _abrir(config)
        g.conexion = Conexion(fisica.cursor(), config["DB_ENGINE"])
    return g.conexion


@contextmanager
def transaccion():
    """Commit automatico; descarta todo si el cuerpo lanza una excepcion."""
    conexion = obtener_conexion()
    try:
        yield conexion
        conexion.commit()
    except Exception:
        conexion.rollback()
        raise


def cerrar_conexion(excepcion=None):
    """Cierra la conexion de la peticion. La registra Flask al terminar."""
    conexion = g.pop("conexion", None)
    if conexion is not None:
        try:
            conexion.cursor.connection.close()
        except Exception:
            pass


def _a_json(valor):
    """Convierte tipos de la base a JSON, exponiendo los booleanos como true/false."""
    if isinstance(valor, bool):
        return valor
    if isinstance(valor, datetime):
        from .time_utils import formatear_instantaneo

        return formatear_instantaneo(valor)
    if isinstance(valor, (date, time)):
        return valor.isoformat()
    return valor


def fila_a_entidad(fila, mapa_bool=()):
    """Normaliza una fila del repositorio al formato JSON de la API."""
    if fila is None:
        return None
    entidad = {}
    for clave, valor in fila.items():
        if clave in mapa_bool:
            entidad[clave] = bool(valor)
        else:
            entidad[clave] = _a_json(valor)
    return entidad
