"""Errores de la aplicacion y su traduccion al sobre {"errors": [...]} del contrato."""


class ApiError(Exception):
    """Error de negocio con codigo HTTP asociado."""

    codigo_http = 400
    codigo = "ERROR"
    level = "error"

    def __init__(self, message, description=None, codigo=None, codigo_http=None, level=None,
                 datos_extra=None):
        super().__init__(message)
        self.message = message
        self.description = description or message
        # El contrato admite campos extra junto a "errors", como "conflictos".
        self.datos_extra = datos_extra or {}
        if codigo is not None:
            self.codigo = codigo
        if codigo_http is not None:
            self.codigo_http = codigo_http
        if level is not None:
            self.level = level

    def a_respuesta(self):
        respuesta = {
            "errors": [
                {
                    "code": self.codigo,
                    "message": self.message,
                    "level": self.level,
                    "description": self.description,
                }
            ]
        }
        # "conflictos" debe quedar al mismo nivel que "errors".
        respuesta.update(self.datos_extra)
        return respuesta


class ErrorValidacion(ApiError):
    """Peticion invalida: campos desconocidos, tipos, formato o rangos."""

    codigo_http = 400
    codigo = "ERROR_VALIDACION"
    level = "error"


class ErrorNoEncontrado(ApiError):
    """El recurso no existe."""

    codigo_http = 404
    codigo = "ERROR_NO_ENCONTRADO"
    level = "error"


class ErrorConflicto(ApiError):
    """El pedido es valido pero choca con el estado actual del sistema."""

    codigo_http = 409
    codigo = "ERROR_CONFLICTO"
    level = "warning"


class ErrorSuperposicion(ErrorConflicto):
    """El intervalo se superpone con otra reserva confirmada."""

    codigo = "ERROR_SUPERPOSICION"


class ErrorDeServidor(ApiError):
    """Fallo inesperado: se registra pero no se filtra el detalle interno."""

    codigo_http = 500
    codigo = "ERROR_INTERNO"
    level = "error"
