"""Convenciones de la seccion 4: validacion de la entrada y traduccion de errores a JSON."""

import re
from urllib.parse import urlencode

from flask import jsonify, request

from .config import (
    PAGINA_LIMITE_MAXIMO,
    PAGINA_LIMITE_MINIMO,
    PAGINA_LIMITE_PREDETERMINADO,
    PAGINA_OFFSET_PREDETERMINADO,
)
from .errors import ApiError, ErrorDeServidor, ErrorValidacion

PATRON_EMAIL = re.compile(r"^[^@\s]+@[^@\s.]+(\.[^@\s.]+)+$")
PATRON_ID = re.compile(r"^\d+$")


def obtener_cuerpo(permitir_vacio=False):
    """Cuerpo de la solicitud como diccionario; uno vacio o no JSON se rechaza con 400."""
    if not request.is_json:
        raise ErrorValidacion(
            "El cuerpo de la solicitud debe ser JSON",
            description=(
                "Falta la cabecera Content-Type: application/json o el cuerpo no es "
                f"un objeto JSON valido. Se recibio: {request.get_data(as_text=True)!r}"
            ),
        )

    datos = request.get_json(silent=True)
    if datos is None:
        raise ErrorValidacion(
            "El cuerpo de la solicitud no es un JSON valido",
            description="No se pudo interpretar el contenido enviado como JSON",
        )
    if not isinstance(datos, dict):
        raise ErrorValidacion(
            "El cuerpo de la solicitud debe ser un objeto JSON",
            description=(
                "Se esperaba un objeto con los campos del recurso y se recibio un "
                f"{type(datos).__name__}"
            ),
        )
    if not datos and not permitir_vacio:
        raise ErrorValidacion(
            "El cuerpo de la solicitud esta vacio",
            description=(
                "Una actualizacion debe incluir al menos un campo. Para repetir el "
                "estado actual de una reserva se envia el mismo estado"
            ),
        )
    return datos


def rechazar_campos_desconocidos(datos, permitidos, contexto):
    """Rechaza con 400 los campos del cuerpo ajenos al recurso."""
    desconocidos = sorted(set(datos) - set(permitidos))
    if desconocidos:
        lista = ", ".join(f"'{c}'" for c in desconocidos)
        raise ErrorValidacion(
            f"El campo {desconocidos[0]!r} no pertenece a {contexto}",
            description=(
                f"Campos no admitidos: {lista}. Solo se aceptan: "
                f"{', '.join(sorted(permitidos))}"
            ),
        )


def rechazar_parametros_desconocidos(permitidos):
    """Rechaza query strings con parametros no contemplados por el endpoint."""
    recibidos = set(request.args.keys())
    desconocidos = sorted(recibidos - set(permitidos))
    if desconocidos:
        lista = ", ".join(f"'{c}'" for c in desconocidos)
        raise ErrorValidacion(
            f"El parametro {desconocidos[0]!r} no es reconocido por este endpoint",
            description=(
                f"Parametros no admitidos: {lista}. Solo se aceptan: "
                f"{', '.join(sorted(permitidos))}"
            ),
        )


def entero_positivo(valor, campo):
    """Convierte a entero exigiendo que sea un entero positivo."""
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise ErrorValidacion(
            f"El campo '{campo}' debe ser un entero positivo",
            description=f"Se recibio {valor!r} en '{campo}'",
        )
    if valor < 1:
        raise ErrorValidacion(
            f"El campo '{campo}' debe ser un entero positivo",
            description=f"El valor {valor} es menor o igual a cero",
        )
    return valor


def entero_opcional(valor, campo):
    """Convierte a entero, o devuelve None si no fue enviado."""
    if valor is None:
        return None
    return entero_positivo(valor, campo)


def entero_opcional_de_query(campo):
    """Query param entero positivo, o None; los query params llegan como texto."""
    valor = request.args.get(campo)
    if valor is None:
        return None
    return entero_positivo(_entero_de_query(valor, campo), campo)


def booleano_estricto(valor, campo):
    """Convierte a booleano admitiendo unicamente los literales "true" y "false"."""
    if isinstance(valor, bool):
        return valor
    if isinstance(valor, str) and valor in ("true", "false"):
        return valor == "true"
    raise ErrorValidacion(
        f"El valor de '{campo}' debe ser true o false",
        description=f"Se recibio {valor!r}. Solo se admiten los literales 'true' y 'false'",
    )


def booleano_opcional(valor, campo):
    """Convierte a booleano, o devuelve None si no fue enviado."""
    if valor is None:
        return None
    return booleano_estricto(valor, campo)


def cadena_no_vacia(valor, campo):
    """Exige una cadena con contenido, ignorando espacios en los extremos."""
    if not isinstance(valor, str):
        raise ErrorValidacion(
            f"El campo '{campo}' debe ser una cadena de texto",
            description=f"Se recibio {type(valor).__name__} en '{campo}'",
        )
    limpio = valor.strip()
    if not limpio:
        raise ErrorValidacion(
            f"El campo '{campo}' no puede quedar vacio",
            description=f"'{campo}' contiene solo espacios en blanco",
        )
    return limpio


def normalizar_email(valor, campo):
    """Valida el correo y lo normaliza a minusculas sin espacios en los extremos."""
    if not isinstance(valor, str):
        raise ErrorValidacion(
            f"El campo '{campo}' debe ser una cadena de texto",
            description=f"Se recibio {type(valor).__name__} en '{campo}'",
        )
    correo = valor.strip().lower()
    if not correo:
        raise ErrorValidacion(
            f"El campo '{campo}' no puede quedar vacio",
            description="El correo electronico es obligatorio",
        )
    if not PATRON_EMAIL.match(correo):
        raise ErrorValidacion(
            "El correo electronico no tiene un formato valido",
            description=(
                f"'{valor}' no cumple el formato de un correo. Se espera algo como "
                "nombre@dominio.com"
            ),
        )
    return correo


def leer_paginacion():
    """_limit entre 1 y 100 (por defecto 10) y _offset mayor o igual a cero (por defecto 0)."""
    crudo_limit = request.args.get("_limit")
    crudo_offset = request.args.get("_offset")

    if crudo_limit is None:
        limite = PAGINA_LIMITE_PREDETERMINADO
    else:
        limite = _entero_de_query(crudo_limit, "_limit")
        if limite < PAGINA_LIMITE_MINIMO or limite > PAGINA_LIMITE_MAXIMO:
            raise ErrorValidacion(
                "El valor de '_limit' esta fuera del rango permitido",
                description=(
                    f"'_limit' es {limite} y el rango permitido es de "
                    f"{PAGINA_LIMITE_MINIMO} a {PAGINA_LIMITE_MAXIMO}"
                ),
            )

    if crudo_offset is None:
        offset = PAGINA_OFFSET_PREDETERMINADO
    else:
        offset = _entero_de_query(crudo_offset, "_offset")
        if offset < 0:
            raise ErrorValidacion(
                "El valor de '_offset' no puede ser negativo",
                description=f"'_offset' es {offset} y debe ser mayor o igual a cero",
            )

    return limite, offset


def _entero_de_query(valor, campo):
    """Interpreta un query param como entero, sin distinguir signos ni espacios."""
    texto = valor.strip()
    if not PATRON_ID.match(texto) and texto != "0":
        raise ErrorValidacion(
            f"El parametro '{campo}' debe ser un entero",
            description=f"Se recibio {valor!r} en '{campo}'",
        )
    return int(texto)


def construir_paginado(clave, elementos, total, limite, offset, endpoint):
    """Arma el sobre de listado con la clave descriptiva y los enlaces HATEOAS."""
    # Ultima pagina alcanzable. Si no hay elementos, la unica pagina posible es 0.
    ultima_pagina = max((total - 1) // limite, 0) if total > 0 else 0
    pagina_actual = offset // limite

    def enlace(nuevo_offset):
        """Reconstruye la URL conservando los filtros originales."""
        argumentos = {clave: valor for clave, valor in request.args.items()}
        argumentos["_limit"] = limite
        argumentos["_offset"] = nuevo_offset
        return f"{request.base_url}?{urlencode(argumentos)}"

    return {
        clave: elementos,
        "_links": {
            "_first": enlace(0),
            "_prev": enlace(max(offset - limite, 0)) if offset > 0 else None,
            "_next": enlace(offset + limite) if pagina_actual < ultima_pagina else None,
            "_last": enlace(ultima_pagina * limite),
        },
    }


def respuesta_ok(datos, codigo=200):
    """200 con cuerpo JSON."""
    return jsonify(datos), codigo


def respuesta_creada(datos, cabeceras=None):
    """201 con el recurso creado y la cabecera Location."""
    respuesta = jsonify(datos)
    respuesta.status_code = 201
    respuesta.headers["Location"] = cabeceras or ""
    return respuesta


def respuesta_sin_contenido():
    """204 sin cuerpo."""
    return "", 204


def registrar_manejadores(app):
    """Registra en la app los handlers que convierten excepciones en el sobre de error."""

    @app.errorhandler(ApiError)
    def manejar_api_error(error):
        respuesta = jsonify(error.a_respuesta())
        respuesta.status_code = error.codigo_http
        return respuesta

    @app.errorhandler(404)
    def manejar_ruta_desconocida(error):
        # Un 404 de Flask es una ruta inexistente, no un recurso inexistente.
        respuesta = jsonify(
            {
                "errors": [
                    {
                        "code": "ERROR_NO_ENCONTRADO",
                        "message": "El recurso solicitado no existe",
                        "level": "error",
                        "description": (
                            f"No hay ninguna ruta que responda a {request.method} "
                            f"{request.path}"
                        ),
                    }
                ]
            }
        )
        respuesta.status_code = 404
        return respuesta

    @app.errorhandler(405)
    def manejar_metodo_no_permitido(error):
        respuesta = jsonify(
            {
                "errors": [
                    {
                        "code": "ERROR_METODO_NO_PERMITIDO",
                        "message": "El metodo HTTP no esta permitido para esta ruta",
                        "level": "error",
                        "description": (
                            f"{request.method} no esta permitido en {request.path}"
                        ),
                    }
                ]
            }
        )
        respuesta.status_code = 405
        return respuesta

    @app.errorhandler(400)
    def manejar_bad_request(error):
        respuesta = jsonify(
            {
                "errors": [
                    {
                        "code": "ERROR_VALIDACION",
                        "message": "La solicitud es invalida",
                        "level": "error",
                        "description": str(getattr(error, "description", error)),
                    }
                ]
            }
        )
        respuesta.status_code = 400
        return respuesta

    @app.errorhandler(Exception)
    def manejar_error_inesperado(error):
        # En pruebas se relanza la excepcion: un fallo inesperado debe romper el test.
        if app.testing:
            raise error

        # Fuera de las pruebas el detalle interno no se filtra: queda en el log.
        app.logger.exception("Error no controlado: %s", error)
        respuesta = jsonify(
            ErrorDeServidor(
                "Ocurrio un error inesperado",
                description=(
                    "La solicitud no pudo completarse. El detalle tecnico quedo "
                    "registrado en el log del servidor"
                ),
            ).a_respuesta()
        )
        respuesta.status_code = 500
        return respuesta


def id_de_ruta(nombre="id"):
    """Lee y valida el identificador de la ruta."""
    return entero_positivo(request.view_args[nombre], nombre)
