"""Bloqueos de mantenimiento, que pueden exceder las tres horas del limite de reservas."""

from ..config import ESTADO_CONFIRMADA
from ..db import fila_a_entidad, obtener_conexion

COLUMNAS = "id, id_cancha, fecha, hora_inicio, hora_fin, motivo"


def _armar_filtros(filtros):
    condiciones = []
    valores = []

    if filtros.get("id_cancha") is not None:
        condiciones.append(" AND id_cancha = %s")
        valores.append(filtros["id_cancha"])

    if filtros.get("fecha") is not None:
        condiciones.append(" AND fecha = %s")
        valores.append(filtros["fecha"])

    return "".join(condiciones), valores


class BloqueosRepo:
    def listar(self, filtros, limite, offset):
        conexion = obtener_conexion()
        condiciones, valores = _armar_filtros(filtros)
        patron = f"FROM bloqueos WHERE 1 = 1{condiciones}"

        total = conexion.obtener_valor(f"SELECT COUNT(*) {patron}", valores, 0)
        filas = conexion.obtener_filas(
            f"SELECT {COLUMNAS} {patron} ORDER BY id ASC LIMIT %s OFFSET %s",
            valores + [limite, offset],
        )
        return [fila_a_entidad(fila) for fila in filas], total

    def obtener_por_id(self, id_bloqueo):
        fila = obtener_conexion().obtener_fila(
            f"SELECT {COLUMNAS} FROM bloqueos WHERE id = %s", (id_bloqueo,)
        )
        return fila_a_entidad(fila)

    def crear(self, id_cancha, fecha, hora_inicio, hora_fin, motivo):
        id_bloqueo = obtener_conexion().insertar(
            "INSERT INTO bloqueos (id_cancha, fecha, hora_inicio, hora_fin, motivo) "
            "VALUES (%s, %s, %s, %s, %s)",
            (id_cancha, fecha, hora_inicio, hora_fin, motivo),
        )
        return self.obtener_por_id(id_bloqueo)

    def eliminar(self, id_bloqueo):
        obtener_conexion().ejecutar("DELETE FROM bloqueos WHERE id = %s", (id_bloqueo,))

    def existe_bloqueo_superpuesto(self, id_cancha, fecha, hora_inicio, hora_fin,
                                   excluir_id=None):
        """Un bloqueo existente impide crear otro superpuesto en la misma cancha."""
        condicion = ""
        argumentos = [id_cancha, fecha, hora_fin, hora_inicio]
        if excluir_id is not None:
            condicion = " AND id <> %s"
            argumentos.append(excluir_id)

        return (
            obtener_conexion().obtener_valor(
                "SELECT COUNT(*) FROM bloqueos"
                " WHERE id_cancha = %s AND fecha = %s"
                "   AND hora_inicio < %s AND hora_fin > %s"
                f"{condicion}",
                argumentos,
                0,
            )
            > 0
        )

    def existe_reserva_confirmada_en_intervalo(self, id_cancha, fecha, hora_inicio,
                                               hora_fin):
        """La comparacion es por fecha y horas sueltas porque el bloqueo no tiene fraccion de segundo."""
        return (
            obtener_conexion().obtener_valor(
                "SELECT COUNT(*) FROM reservas"
                " WHERE id_cancha = %s AND estado = %s"
                "   AND DATE(fecha_hora_inicio) = %s"
                "   AND TIME(fecha_hora_inicio) < %s AND TIME(fecha_hora_fin) > %s",
                (id_cancha, ESTADO_CONFIRMADA, fecha, hora_fin, hora_inicio),
                0,
            )
            > 0
        )
