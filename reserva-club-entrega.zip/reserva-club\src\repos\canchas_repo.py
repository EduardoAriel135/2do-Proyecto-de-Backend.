"""Consultas parametrizadas: los fragmentos SQL se acumulan junto a sus valores para que el orden coincida."""

from ..db import fila_a_entidad, obtener_conexion

MAPA_BOOL = ("techada", "activa")


def _armar_filtros(alcance, filtros):
    """Devuelve el fragmento SQL (con " AND " inicial) y los valores de los filtros."""
    condiciones = []
    valores = []

    if filtros.get("id_deporte") is not None:
        condiciones.append(f" AND {alcance}id_deporte = %s")
        valores.append(filtros["id_deporte"])

    if filtros.get("nombre") is not None:
        # LOWER en columna y valor: MySQL resuelve la insensitividad con la collation.
        condiciones.append(f" AND LOWER({alcance}nombre) LIKE LOWER(%s)")
        valores.append(f"%{filtros['nombre']}%")

    for campo in ("techada", "activa"):
        if filtros.get(campo) is not None:
            condiciones.append(f" AND {alcance}{campo} = %s")
            valores.append(1 if filtros[campo] else 0)

    return "".join(condiciones), valores


class CanchasRepo:
    def listar(self, filtros, limite, offset):
        """Pagina de canchas; el total se cuenta sobre el mismo filtro porque se filtra antes de paginar."""
        conexion = obtener_conexion()
        condiciones, valores = _armar_filtros("c.", filtros)
        patron = f"FROM canchas c WHERE 1 = 1{condiciones}"

        total = conexion.obtener_valor(f"SELECT COUNT(*) {patron}", valores, 0)
        filas = conexion.obtener_filas(
            f"SELECT c.id, c.nombre, c.id_deporte, c.precio_hora, c.techada, c.activa "
            f"{patron} ORDER BY c.id ASC LIMIT %s OFFSET %s",
            valores + [limite, offset],
        )
        return [fila_a_entidad(fila, MAPA_BOOL) for fila in filas], total

    def obtener_por_id(self, id_cancha):
        fila = obtener_conexion().obtener_fila(
            "SELECT id, nombre, id_deporte, precio_hora, techada, activa "
            "FROM canchas WHERE id = %s",
            (id_cancha,),
        )
        return fila_a_entidad(fila, MAPA_BOOL)

    def crear(self, nombre, id_deporte, precio_hora, techada, activa):
        id_cancha = obtener_conexion().insertar(
            "INSERT INTO canchas (nombre, id_deporte, precio_hora, techada, activa) "
            "VALUES (%s, %s, %s, %s, %s)",
            (
                nombre,
                id_deporte,
                precio_hora,
                1 if techada else 0,
                1 if activa else 0,
            ),
        )
        return self.obtener_por_id(id_cancha)

    def actualizar(self, id_cancha, cambios):
        """Actualizacion parcial: solo se escriben los campos presentes en `cambios`."""
        if not cambios:
            return self.obtener_por_id(id_cancha)

        asignaciones = []
        valores = []
        for campo in ("nombre", "precio_hora", "techada", "activa"):
            if campo not in cambios:
                continue
            asignaciones.append(f"{campo} = %s")
            valor = cambios[campo]
            if campo in ("techada", "activa"):
                valor = 1 if valor else 0
            valores.append(valor)

        valores.append(id_cancha)
        obtener_conexion().ejecutar(
            f"UPDATE canchas SET {', '.join(asignaciones)} WHERE id = %s", valores
        )
        return self.obtener_por_id(id_cancha)

    def eliminar(self, id_cancha):
        obtener_conexion().ejecutar("DELETE FROM canchas WHERE id = %s", (id_cancha,))

    def contar_reservas(self, id_cancha):
        """Cuenta tambien las canceladas: no se puede eliminar una cancha con reservas en cualquier estado."""
        return obtener_conexion().obtener_valor(
            "SELECT COUNT(*) FROM reservas WHERE id_cancha = %s", (id_cancha,), 0
        )

    def listar_disponibles(self, filtros, inicio, fin, fecha, hora_inicio, hora_fin,
                           limite, offset):
        """Canchas activas libres en [inicio, fin): dos NOT EXISTS descartan ocupantes superpuestos (a < d AND c < b) y los bloqueos se restan con la misma logica."""
        conexion = obtener_conexion()
        condiciones, valores = _armar_filtros("c.", filtros)

        superposicion_reservas = (
            " AND NOT EXISTS ("
            "   SELECT 1 FROM reservas r"
            "    WHERE r.id_cancha = c.id"
            "      AND r.estado = 'confirmada'"
            "      AND r.fecha_hora_inicio < %s"
            "      AND r.fecha_hora_fin > %s"
            " )"
        )
        valores_superposicion = [fin, inicio]

        consideracion_bloqueos = (
            " AND NOT EXISTS ("
            "   SELECT 1 FROM bloqueos b"
            "    WHERE b.id_cancha = c.id"
            "      AND b.fecha = %s"
            "      AND b.hora_inicio < %s"
            "      AND b.hora_fin > %s"
            " )"
        )
        valores_bloqueos = [fecha, hora_fin, hora_inicio]

        patron = (
            f"FROM canchas c WHERE c.activa = %s{condiciones}"
            f"{superposicion_reservas}{consideracion_bloqueos}"
        )
        argumentos = [1] + valores + valores_superposicion + valores_bloqueos

        total = conexion.obtener_valor(f"SELECT COUNT(*) {patron}", argumentos, 0)
        filas = conexion.obtener_filas(
            f"SELECT c.id, c.nombre, c.id_deporte, c.precio_hora, c.techada, c.activa "
            f"{patron} ORDER BY c.id ASC LIMIT %s OFFSET %s",
            argumentos + [limite, offset],
        )
        return [fila_a_entidad(fila, MAPA_BOOL) for fila in filas], total
