"""Deportes precargados por script de inicializacion: la API no los administra."""

from ..db import fila_a_entidad, obtener_conexion


class DeportesRepo:
    def listar(self):
        """Sin paginacion: la consulta de deportes precargados no la requiere."""
        filas = obtener_conexion().obtener_filas(
            "SELECT id, nombre FROM deportes ORDER BY id ASC"
        )
        return [fila_a_entidad(fila) for fila in filas]

    def obtener_por_id(self, id_deporte):
        fila = obtener_conexion().obtener_fila(
            "SELECT id, nombre FROM deportes WHERE id = %s", (id_deporte,)
        )
        return fila_a_entidad(fila)

    def obtener_por_nombre(self, nombre):
        """Busqueda exacta, usada para normalizar el filtro por nombre."""
        fila = obtener_conexion().obtener_fila(
            "SELECT id, nombre FROM deportes WHERE nombre = %s", (nombre,)
        )
        return fila_a_entidad(fila)
