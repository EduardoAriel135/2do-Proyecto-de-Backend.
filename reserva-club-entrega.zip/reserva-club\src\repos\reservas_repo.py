"""Solapamiento de intervalos semiabiertos: inicio_ocupado < fin_pedido AND fin_ocupado > inicio_pedido; solo reservas confirmadas."""

from ..config import ESTADO_CONFIRMADA
from ..db import fila_a_entidad, obtener_conexion

COLUMNAS = (
    "id, id_socio, id_cancha, fecha_hora_inicio, fecha_hora_fin, estado, "
    "precio_hora, precio_total"
)

_PROYECCION_CONFLICTO = "id, id_cancha, id_socio, fecha_hora_inicio, fecha_hora_fin"


def _armar_filtros(filtros):
    """El rango de fechas se aplica al dia de utilizacion, con ambos extremos inclusive."""
    condiciones = []
    valores = []

    for campo in ("id_cancha", "id_socio"):
        if filtros.get(campo) is not None:
            condiciones.append(f" AND {campo} = %s")
            valores.append(filtros[campo])

    if filtros.get("estado") is not None:
        condiciones.append(" AND estado = %s")
        valores.append(filtros["estado"])

    if filtros.get("fecha_desde") is not None:
        condiciones.append(" AND fecha_hora_inicio >= %s")
        valores.append(filtros["fecha_desde"])

    if filtros.get("fecha_hasta") is not None:
        condiciones.append(" AND fecha_hora_inicio < %s")
        valores.append(filtros["fecha_hasta"])

    return "".join(condiciones), valores


class ReservasRepo:
    def listar(self, filtros, limite, offset):
        conexion = obtener_conexion()
        condiciones, valores = _armar_filtros(filtros)
        patron = f"FROM reservas WHERE 1 = 1{condiciones}"

        total = conexion.obtener_valor(f"SELECT COUNT(*) {patron}", valores, 0)
        filas = conexion.obtener_filas(
            f"SELECT {COLUMNAS} {patron} ORDER BY id ASC LIMIT %s OFFSET %s",
            valores + [limite, offset],
        )
        return [fila_a_entidad(fila) for fila in filas], total

    def obtener_por_id(self, id_reserva):
        fila = obtener_conexion().obtener_fila(
            f"SELECT {COLUMNAS} FROM reservas WHERE id = %s", (id_reserva,)
        )
        return fila_a_entidad(fila)

    def crear(self, id_socio, id_cancha, inicio, fin, precio_hora, precio_total):
        """El estado inicial lo fija el servidor y el precio llega calculado por el servicio, no del cliente."""
        id_reserva = obtener_conexion().insertar(
            "INSERT INTO reservas (id_socio, id_cancha, fecha_hora_inicio, "
            "fecha_hora_fin, estado, precio_hora, precio_total) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (
                id_socio,
                id_cancha,
                inicio,
                fin,
                ESTADO_CONFIRMADA,
                precio_hora,
                precio_total,
            ),
        )
        return self.obtener_por_id(id_reserva)

    def crear_varias(self, reservas):
        """Varias reservas en la misma transaccion: si una falla, no queda ninguna a medias."""
        conexion = obtener_conexion()
        ids = []
        for id_socio, id_cancha, inicio, fin, precio_hora, precio_total in reservas:
            ids.append(
                conexion.insertar(
                    "INSERT INTO reservas (id_socio, id_cancha, fecha_hora_inicio, "
                    "fecha_hora_fin, estado, precio_hora, precio_total) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    (
                        id_socio,
                        id_cancha,
                        inicio,
                        fin,
                        ESTADO_CONFIRMADA,
                        precio_hora,
                        precio_total,
                    ),
                )
            )
        return ids

    def actualizar_estado(self, id_reserva, estado):
        obtener_conexion().ejecutar(
            "UPDATE reservas SET estado = %s WHERE id = %s", (estado, id_reserva)
        )
        return self.obtener_por_id(id_reserva)

    def contar_por_id_cancha(self, id_cancha, estado=None):
        if estado is None:
            return obtener_conexion().obtener_valor(
                "SELECT COUNT(*) FROM reservas WHERE id_cancha = %s", (id_cancha,), 0
            )
        return obtener_conexion().obtener_valor(
            "SELECT COUNT(*) FROM reservas WHERE id_cancha = %s AND estado = %s",
            (id_cancha, estado),
            0,
        )

    def contar_por_id_socio(self, id_socio, estado=None):
        if estado is None:
            return obtener_conexion().obtener_valor(
                "SELECT COUNT(*) FROM reservas WHERE id_socio = %s", (id_socio,), 0
            )
        return obtener_conexion().obtener_valor(
            "SELECT COUNT(*) FROM reservas WHERE id_socio = %s AND estado = %s",
            (id_socio, estado),
            0,
        )

    def detectar_conflictos(self, id_socio, id_cancha, inicio, fin, excluir_id=None):
        """Reservas confirmadas superpuestas, distinguiendo en_cancha y en_socio para que el 409 diga cual fallo."""
        condicion_exclusion = ""
        argumentos = [ESTADO_CONFIRMADA, fin, inicio]
        if excluir_id is not None:
            condicion_exclusion = " AND id <> %s"
            argumentos.append(excluir_id)

        filas = obtener_conexion().obtener_filas(
            f"SELECT {_PROYECCION_CONFLICTO} FROM reservas"
            " WHERE estado = %s AND fecha_hora_inicio < %s AND fecha_hora_fin > %s"
            f"{condicion_exclusion}",
            argumentos,
        )

        return {
            "en_cancha": any(fila["id_cancha"] == id_cancha for fila in filas),
            "en_socio": any(fila["id_socio"] == id_socio for fila in filas),
            "total": len(filas),
            "reservas": [fila_a_entidad(fila) for fila in filas],
        }

    def existe_superposicion_en_cancha(self, id_cancha, inicio, fin):
        return self.detectar_conflictos(0, id_cancha, inicio, fin)["en_cancha"]

    def existe_superposicion_en_socio(self, id_socio, inicio, fin):
        return self.detectar_conflictos(id_socio, 0, inicio, fin)["en_socio"]
