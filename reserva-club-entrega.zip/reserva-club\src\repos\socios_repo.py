"""Busqueda por nombre parcial e insensible a mayusculas; el correo se busca ya normalizado."""

from ..db import fila_a_entidad, obtener_conexion

MAPA_BOOL = ("activo",)


def _armar_filtros(filtros):
    condiciones = []
    valores = []

    if filtros.get("nombre") is not None:
        condiciones.append(" AND LOWER(nombre) LIKE LOWER(%s)")
        valores.append(f"%{filtros['nombre']}%")

    if filtros.get("activo") is not None:
        condiciones.append(" AND activo = %s")
        valores.append(1 if filtros["activo"] else 0)

    return "".join(condiciones), valores


class SociosRepo:
    def listar(self, filtros, limite, offset):
        conexion = obtener_conexion()
        condiciones, valores = _armar_filtros(filtros)
        patron = f"FROM socios WHERE 1 = 1{condiciones}"

        total = conexion.obtener_valor(f"SELECT COUNT(*) {patron}", valores, 0)
        filas = conexion.obtener_filas(
            f"SELECT id, nombre, email, activo {patron} ORDER BY id ASC LIMIT %s OFFSET %s",
            valores + [limite, offset],
        )
        return [fila_a_entidad(fila, MAPA_BOOL) for fila in filas], total

    def obtener_por_id(self, id_socio):
        fila = obtener_conexion().obtener_fila(
            "SELECT id, nombre, email, activo FROM socios WHERE id = %s", (id_socio,)
        )
        return fila_a_entidad(fila, MAPA_BOOL)

    def obtener_por_email(self, email):
        """No filtra por `activo` porque el correo debe ser unico tambien entre socios inactivos."""
        fila = obtener_conexion().obtener_fila(
            "SELECT id, nombre, email, activo FROM socios WHERE email = %s", (email,)
        )
        return fila_a_entidad(fila, MAPA_BOOL)

    def crear(self, nombre, email, activo):
        id_socio = obtener_conexion().insertar(
            "INSERT INTO socios (nombre, email, activo) VALUES (%s, %s, %s)",
            (nombre, email, 1 if activo else 0),
        )
        return self.obtener_por_id(id_socio)

    def actualizar(self, id_socio, cambios):
        if not cambios:
            return self.obtener_por_id(id_socio)

        asignaciones = []
        valores = []
        for campo in ("nombre", "email", "activo"):
            if campo not in cambios:
                continue
            asignaciones.append(f"{campo} = %s")
            valor = cambios[campo]
            if campo == "activo":
                valor = 1 if valor else 0
            valores.append(valor)

        valores.append(id_socio)
        obtener_conexion().ejecutar(
            f"UPDATE socios SET {', '.join(asignaciones)} WHERE id = %s", valores
        )
        return self.obtener_por_id(id_socio)
