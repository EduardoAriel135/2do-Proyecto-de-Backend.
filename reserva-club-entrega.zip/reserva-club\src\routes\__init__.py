"""Capa HTTP: cada modulo expone un blueprint y delega las reglas en su servicio."""
