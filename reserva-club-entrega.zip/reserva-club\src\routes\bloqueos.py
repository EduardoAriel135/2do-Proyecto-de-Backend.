from flask import Blueprint, request

from ..http import (
    construir_paginado,
    entero_opcional_de_query,
    entero_positivo,
    obtener_cuerpo,
    leer_paginacion,
    rechazar_campos_desconocidos,
    rechazar_parametros_desconocidos,
    respuesta_creada,
    respuesta_ok,
    respuesta_sin_contenido,
)
from ..services.bloqueos_service import BloqueosService
from ..time_utils import parsear_fecha

bp = Blueprint("bloqueos", __name__)

servicio = BloqueosService()

CAMPOS_ALTA = ("id_cancha", "fecha", "hora_inicio", "hora_fin", "motivo")
PARAMETROS_LISTADO = ("id_cancha", "fecha", "_limit", "_offset")


@bp.get("/bloqueos")
def listar_bloqueos():
    """GET /bloqueos: listado paginado ordenado por id ascendente."""
    rechazar_parametros_desconocidos(PARAMETROS_LISTADO)
    filtros = {
        "id_cancha": entero_opcional_de_query("id_cancha"),
        "fecha": _leer_fecha(request.args.get("fecha")),
    }
    limite, offset = leer_paginacion()

    bloqueos, total = servicio.listar(filtros, limite, offset)
    return respuesta_ok(
        construir_paginado("bloqueos", bloqueos, total, limite, offset, "bloqueos")
    )


@bp.post("/bloqueos")
def crear_bloqueo():
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_ALTA, "un bloqueo")

    bloqueo = servicio.crear(datos)
    return respuesta_creada(bloqueo, cabeceras=f"/bloqueos/{bloqueo['id']}")


@bp.delete("/bloqueos/<int:id_bloqueo>")
def eliminar_bloqueo(id_bloqueo):
    """DELETE /bloqueos/{id}: quita el bloqueo, no las reservas de esa franja."""
    rechazar_parametros_desconocidos(())
    entero_positivo(id_bloqueo, "id")
    servicio.eliminar(id_bloqueo)
    return respuesta_sin_contenido()


def _leer_fecha(valor):
    if valor is None:
        return None
    return parsear_fecha(valor, "fecha")
