from flask import Blueprint, request

from ..errors import ErrorValidacion
from ..http import (
    booleano_opcional,
    construir_paginado,
    entero_opcional_de_query,
    entero_positivo,
    obtener_cuerpo,
    leer_paginacion,
    rechazar_campos_desconocidos,
    rechazar_parametros_desconocidos,
    respuesta_creada,
    respuesta_ok,
    respuesta_sin_contenido,
)
from ..services.canchas_service import CanchasService
from ..time_utils import parsear_fecha, parsear_hora

bp = Blueprint("canchas", __name__)

servicio = CanchasService()

CAMPOS_ALTA = ("nombre", "id_deporte", "precio_hora", "techada", "activa")
CAMPOS_PATCH = ("nombre", "precio_hora", "techada", "activa")
PARAMETROS_LISTADO = ("id_deporte", "nombre", "techada", "activa", "_limit", "_offset")
PARAMETROS_DISPONIBLES = (
    "fecha",
    "hora_inicio",
    "hora_fin",
    "id_deporte",
    "techada",
    "_limit",
    "_offset",
)


@bp.get("/canchas")
def listar_canchas():
    """GET /canchas: sin filtros se listan tambien las canchas inactivas."""
    rechazar_parametros_desconocidos(PARAMETROS_LISTADO)
    filtros = {
        "id_deporte": entero_opcional_de_query("id_deporte"),
        "nombre": request.args.get("nombre"),
        "techada": booleano_opcional(request.args.get("techada"), "techada"),
        "activa": booleano_opcional(request.args.get("activa"), "activa"),
    }
    limite, offset = leer_paginacion()

    canchas, total = servicio.listar(filtros, limite, offset)
    return respuesta_ok(
        construir_paginado("canchas", canchas, total, limite, offset, "canchas")
    )


@bp.post("/canchas")
def crear_cancha():
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_ALTA, "una cancha")

    cancha = servicio.crear(datos)
    return respuesta_creada(cancha, cabeceras=f"/canchas/{cancha['id']}")


@bp.get("/canchas/disponibles")
def listar_canchas_disponibles():
    """GET /canchas/disponibles: solo informa, no retiene ni crea reservas."""
    rechazar_parametros_desconocidos(PARAMETROS_DISPONIBLES)

    faltantes = [
        campo
        for campo in ("fecha", "hora_inicio", "hora_fin")
        if request.args.get(campo) is None
    ]
    if faltantes:
        lista = ", ".join(f"'{campo}'" for campo in faltantes)
        raise ErrorValidacion(
            "Faltan parametros obligatorios para consultar disponibilidad",
            description=f"Parametros obligatorios ausentes: {lista}",
        )

    fecha = parsear_fecha(request.args.get("fecha"), "fecha")
    hora_inicio = parsear_hora(request.args.get("hora_inicio"), "hora_inicio")
    hora_fin = parsear_hora(request.args.get("hora_fin"), "hora_fin")

    filtros = {
        "id_deporte": entero_opcional_de_query("id_deporte"),
        "techada": booleano_opcional(request.args.get("techada"), "techada"),
    }
    limite, offset = leer_paginacion()

    canchas, total = servicio.listar_disponibles(
        filtros, fecha, hora_inicio, hora_fin, limite, offset
    )
    return respuesta_ok(
        construir_paginado(
            "canchas", canchas, total, limite, offset, "canchas_disponibles"
        )
    )


@bp.get("/canchas/<int:id_cancha>")
def obtener_cancha(id_cancha):
    """GET /canchas/{id}: 'activa' indica habilitada para reservar, no libre todo el dia."""
    rechazar_parametros_desconocidos(())
    entero_positivo(id_cancha, "id")
    return respuesta_ok(servicio.obtener(id_cancha))


@bp.patch("/canchas/<int:id_cancha>")
def actualizar_cancha(id_cancha):
    """PATCH /canchas/{id}: el precio no altera los importes de reservas ya existentes."""
    rechazar_parametros_desconocidos(())
    entero_positivo(id_cancha, "id")
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_PATCH, "una cancha")

    cancha = servicio.actualizar(id_cancha, datos)
    return respuesta_ok(cancha)


@bp.delete("/canchas/<int:id_cancha>")
def eliminar_cancha(id_cancha):
    """DELETE /canchas/{id}: con reservas asociadas responde 409; la via es desactivarla."""
    rechazar_parametros_desconocidos(())
    entero_positivo(id_cancha, "id")
    servicio.eliminar(id_cancha)
    return respuesta_sin_contenido()
