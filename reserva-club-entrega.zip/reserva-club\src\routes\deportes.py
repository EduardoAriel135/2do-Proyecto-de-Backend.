from flask import Blueprint, jsonify

from ..http import rechazar_parametros_desconocidos
from ..services.deportes_service import DeportesService

bp = Blueprint("deportes", __name__)

servicio = DeportesService()


@bp.get("/deportes")
def listar_deportes():
    # Sin paginacion, asi que _limit y _offset tampoco son validos aqui.
    rechazar_parametros_desconocidos(())
    return jsonify({"deportes": servicio.listar()}), 200
