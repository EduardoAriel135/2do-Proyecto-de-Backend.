from datetime import datetime, time, timedelta

from flask import Blueprint, request

from ..config import ESTADOS_RESERVA
from ..errors import ErrorValidacion
from ..http import (
    construir_paginado,
    entero_opcional_de_query,
    entero_positivo,
    obtener_cuerpo,
    leer_paginacion,
    rechazar_campos_desconocidos,
    rechazar_parametros_desconocidos,
    respuesta_creada,
    respuesta_ok,
)
from ..services.reservas_service import ReservasService
from ..time_utils import parsear_fecha

bp = Blueprint("reservas", __name__)

servicio = ReservasService()

CAMPOS_ALTA = ("id_socio", "id_cancha", "fecha_hora_inicio", "fecha_hora_fin")
CAMPOS_ESTADO = ("estado",)
PARAMETROS_LISTADO = (
    "id_cancha",
    "id_socio",
    "estado",
    "fecha_desde",
    "fecha_hasta",
    "_limit",
    "_offset",
)


@bp.get("/reservas")
def listar_reservas():
    """GET /reservas: el rango de fechas aplica al dia de uso, con extremos incluidos."""
    rechazar_parametros_desconocidos(PARAMETROS_LISTADO)
    filtros = {
        "id_cancha": entero_opcional_de_query("id_cancha"),
        "id_socio": entero_opcional_de_query("id_socio"),
        "estado": _leer_estado(request.args.get("estado")),
        "fecha_desde": _leer_frontera_fecha(request.args.get("fecha_desde"), "fecha_desde"),
        "fecha_hasta": _leer_frontera_fecha(request.args.get("fecha_hasta"), "fecha_hasta"),
    }

    if (
        filtros["fecha_desde"] is not None
        and filtros["fecha_hasta"] is not None
        and filtros["fecha_desde"] > filtros["fecha_hasta"]
    ):
        raise ErrorValidacion(
            "El rango de fechas es invalido",
            description=(
                f"fecha_desde ({filtros['fecha_desde']}) debe ser menor o igual que "
                f"fecha_hasta ({filtros['fecha_hasta']})"
            ),
        )

    limite, offset = leer_paginacion()
    reservas, total = servicio.listar(filtros, limite, offset)
    return respuesta_ok(
        construir_paginado("reservas", reservas, total, limite, offset, "reservas")
    )


@bp.post("/reservas")
def crear_reserva():
    """POST /reservas: si falla alguna validacion no se guarda nada."""
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_ALTA, "una reserva")

    reserva = servicio.crear(datos)
    return respuesta_creada(reserva, cabeceras=f"/reservas/{reserva['id']}")


@bp.get("/reservas/<int:id_reserva>")
def obtener_reserva(id_reserva):
    rechazar_parametros_desconocidos(())
    entero_positivo(id_reserva, "id")
    return respuesta_ok(servicio.obtener(id_reserva))


@bp.put("/reservas/<int:id_reserva>/estado")
def cambiar_estado_reserva(id_reserva):
    """PUT /reservas/{id}/estado: repetir el estado actual responde 200 sin cambios."""
    rechazar_parametros_desconocidos(())
    entero_positivo(id_reserva, "id")
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_ESTADO, "un cambio de estado")

    reserva = servicio.cambiar_estado(id_reserva, datos)
    return respuesta_ok(reserva)


def _leer_estado(valor):
    """Filtro de estado: lo desconocido se rechaza con 400 en vez de listar vacio."""
    if valor is None:
        return None
    if valor not in ESTADOS_RESERVA:
        raise ErrorValidacion(
            "El valor del filtro 'estado' no es valido",
            description=(
                f"'{valor}' no es un estado conocido. Los estados validos son: "
                f"{', '.join(ESTADOS_RESERVA)}"
            ),
        )
    return valor


def _leer_frontera_fecha(valor, campo):
    """Acota el rango: fecha_desde a medianoche, fecha_hasta al dia siguiente para incluirlo."""
    if valor is None:
        return None
    fecha = parsear_fecha(valor, campo)
    if campo == "fecha_desde":
        return datetime.combine(fecha, time.min)
    return datetime.combine(fecha + timedelta(days=1), time.min)
