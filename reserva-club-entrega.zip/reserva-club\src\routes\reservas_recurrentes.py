from flask import Blueprint, jsonify

from ..http import (
    obtener_cuerpo,
    rechazar_campos_desconocidos,
    rechazar_parametros_desconocidos,
)
from ..services.reservas_recurrentes_service import (
    CAMPOS_OBLIGATORIOS,
    ReservasRecurrentesService,
)

bp = Blueprint("reservas_recurrentes", __name__)

servicio = ReservasRecurrentesService()


@bp.post("/reservas/recurrentes")
def crear_reservas_recurrentes():
    """POST /reservas/recurrentes: si una fecha no esta libre, responde 409 sin guardar nada."""
    rechazar_parametros_desconocidos(())
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_OBLIGATORIOS, "una serie de reservas")

    reservas = servicio.crear(datos)
    respuesta = jsonify({"reservas": reservas})
    respuesta.status_code = 201
    respuesta.headers["Location"] = f"/reservas/{reservas[0]['id']}"
    return respuesta
