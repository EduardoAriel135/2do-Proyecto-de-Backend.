from flask import Blueprint, request

from ..http import (
    booleano_opcional,
    construir_paginado,
    entero_positivo,
    obtener_cuerpo,
    leer_paginacion,
    rechazar_campos_desconocidos,
    rechazar_parametros_desconocidos,
    respuesta_creada,
    respuesta_ok,
)
from ..services.socios_service import SociosService

bp = Blueprint("socios", __name__)

servicio = SociosService()

# Campos admitidos por endpoint; cualquier otro se rechaza con 400.
CAMPOS_ALTA = ("nombre", "email")
CAMPOS_PATCH = ("nombre", "email", "activo")
PARAMETROS_LISTADO = ("nombre", "activo", "_limit", "_offset")


@bp.get("/socios")
def listar_socios():
    """GET /socios: sin filtros se listan tambien los socios inactivos."""
    rechazar_parametros_desconocidos(PARAMETROS_LISTADO)
    filtros = {
        "nombre": request.args.get("nombre"),
        "activo": booleano_opcional(request.args.get("activo"), "activo"),
    }
    limite, offset = leer_paginacion()

    socios, total = servicio.listar(filtros, limite, offset)
    return respuesta_ok(
        construir_paginado("socios", socios, total, limite, offset, "socios")
    )


@bp.post("/socios")
def crear_socio():
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_ALTA, "un socio")

    socio = servicio.crear(datos)
    return respuesta_creada(socio, cabeceras=f"/socios/{socio['id']}")


@bp.get("/socios/<int:id_socio>")
def obtener_socio(id_socio):
    rechazar_parametros_desconocidos(())
    entero_positivo(id_socio, "id")
    return respuesta_ok(servicio.obtener(id_socio))


@bp.patch("/socios/<int:id_socio>")
def actualizar_socio(id_socio):
    """PATCH /socios/{id}: actualizacion parcial; 409 si el email ya esta en uso."""
    rechazar_parametros_desconocidos(())
    entero_positivo(id_socio, "id")
    datos = obtener_cuerpo()
    rechazar_campos_desconocidos(datos, CAMPOS_PATCH, "un socio")

    socio = servicio.actualizar(id_socio, datos)
    return respuesta_ok(socio)
