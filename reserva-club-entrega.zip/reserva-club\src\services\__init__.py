"""Servicios: capa de reglas de negocio."""
