"""Reglas de negocio de los bloqueos de mantenimiento."""

from datetime import datetime

from ..db import transaccion
from ..errors import ErrorConflicto, ErrorNoEncontrado, ErrorValidacion
from ..http import cadena_no_vacia, entero_positivo
from ..repos.bloqueos_repo import BloqueosRepo
from ..repos.canchas_repo import CanchasRepo
from ..time_utils import (
    ahora_del_club,
    formatear_instantaneo,
    parsear_fecha,
    parsear_hora,
    validar_horario_del_club,
    validar_horas_en_punto,
)

CAMPOS_OBLIGATORIOS = ("id_cancha", "fecha", "hora_inicio", "hora_fin", "motivo")

# Puede ocupar toda la jornada, a diferencia de una reserva.
DURACION_MAXIMA_BLOQUEO_HORAS = 15


class BloqueosService:
    def __init__(self, repo=None, canchas_repo=None):
        self._repo = repo or BloqueosRepo()
        self._canchas = canchas_repo or CanchasRepo()

    def listar(self, filtros, limite, offset):
        return self._repo.listar(filtros, limite, offset)

    def obtener(self, id_bloqueo):
        bloqueo = self._repo.obtener_por_id(id_bloqueo)
        if bloqueo is None:
            raise ErrorNoEncontrado(
                f"No existe un bloqueo con id {id_bloqueo}",
                description=f"El bloqueo {id_bloqueo} no esta registrado",
            )
        return bloqueo

    def crear(self, datos):
        faltantes = [campo for campo in CAMPOS_OBLIGATORIOS if campo not in datos]
        if faltantes:
            lista = ", ".join(f"'{campo}'" for campo in faltantes)
            raise ErrorValidacion(
                "Faltan campos obligatorios para crear un bloqueo",
                description=f"Campos obligatorios ausentes: {lista}",
            )

        id_cancha = entero_positivo(datos["id_cancha"], "id_cancha")
        fecha = parsear_fecha(datos["fecha"], "fecha")
        hora_inicio = parsear_hora(datos["hora_inicio"], "hora_inicio")
        hora_fin = parsear_hora(datos["hora_fin"], "hora_fin")
        motivo = cadena_no_vacia(datos["motivo"], "motivo")

        self._validar_intervalo(fecha, hora_inicio, hora_fin)

        with transaccion():
            self._verificar_cancha(id_cancha)

            if self._repo.existe_bloqueo_superpuesto(
                id_cancha, fecha, hora_inicio, hora_fin
            ):
                raise ErrorConflicto(
                    "La franja ya esta bloqueada",
                    description=(
                        f"Ya existe un bloqueo de mantenimiento para la cancha "
                        f"{id_cancha} el {fecha.isoformat()} que se superpone con "
                        f"{hora_inicio.strftime('%H:%M')} - {hora_fin.strftime('%H:%M')}"
                    ),
                )

            if self._repo.existe_reserva_confirmada_en_intervalo(
                id_cancha, fecha, hora_inicio, hora_fin
            ):
                raise ErrorConflicto(
                    "La franja tiene reservas confirmadas",
                    description=(
                        f"No se puede bloquear porque la cancha {id_cancha} tiene "
                        f"reservas confirmadas el {fecha.isoformat()} dentro del "
                        "intervalo solicitado. Cancelelas antes de bloquear"
                    ),
                )

            return self._repo.crear(id_cancha, fecha, hora_inicio, hora_fin, motivo)

    def eliminar(self, id_bloqueo):
        """Quita el bloqueo sin tocar las reservas, la cancha ni los socios."""
        with transaccion():
            self.obtener(id_bloqueo)
            self._repo.eliminar(id_bloqueo)

    @staticmethod
    def _validar_intervalo(fecha, hora_inicio, hora_fin):
        """No se limita a tres horas: el enunciado pide poder bloquear la jornada completa."""
        if hora_inicio >= hora_fin:
            raise ErrorValidacion(
                "El intervalo del bloqueo es invalido",
                description=(
                    "Se requiere hora_inicio < hora_fin. Se recibio inicio "
                    f"{hora_inicio.strftime('%H:%M:%S')} y fin "
                    f"{hora_fin.strftime('%H:%M:%S')}"
                ),
            )

        inicio = datetime.combine(fecha, hora_inicio)
        fin = datetime.combine(fecha, hora_fin)

        validar_horas_en_punto(hora_inicio, "hora_inicio")
        validar_horas_en_punto(hora_fin, "hora_fin")
        validar_horario_del_club(inicio, fin)

        duracion = (fin - inicio).total_seconds() / 3600
        if duracion > DURACION_MAXIMA_BLOQUEO_HORAS:
            raise ErrorValidacion(
                "La duracion del bloqueo es invalida",
                description=(
                    f"El bloqueo dura {duracion:g} horas y el maximo es "
                    f"{DURACION_MAXIMA_BLOQUEO_HORAS} horas, que es la jornada "
                    "completa del club (08:00 a 23:00)"
                ),
            )

        ahora = ahora_del_club()
        if inicio <= ahora:
            raise ErrorValidacion(
                "No se pueden crear bloqueos en fechas u horarios pasados",
                description=(
                    f"El bloqueo comienza el {formatear_instantaneo(inicio)} y el "
                    f"momento actual del club es {formatear_instantaneo(ahora)}. "
                    "Los bloqueos deben comenzar en el futuro"
                ),
            )

    def _verificar_cancha(self, id_cancha):
        cancha = self._canchas.obtener_por_id(id_cancha)
        if cancha is None:
            raise ErrorNoEncontrado(
                f"No existe una cancha con id {id_cancha}",
                description=f"La cancha {id_cancha} no esta registrada en el club",
            )
        return cancha
