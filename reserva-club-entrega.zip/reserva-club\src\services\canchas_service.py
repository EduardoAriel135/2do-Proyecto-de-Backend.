"""Reglas de negocio de las canchas."""

from datetime import datetime

from ..db import transaccion
from ..errors import ErrorConflicto, ErrorNoEncontrado, ErrorValidacion
from ..http import cadena_no_vacia, entero_positivo
from ..repos.canchas_repo import CanchasRepo
from ..repos.deportes_repo import DeportesRepo
from ..time_utils import validar_intervalo

CAMPOS_OBLIGATORIOS = ("nombre", "id_deporte", "precio_hora")
CAMPOS_EDITABLES = ("nombre", "precio_hora", "techada", "activa")

TECHADA_POR_DEFECTO = False
ACTIVA_POR_DEFECTO = True


class CanchasService:
    def __init__(self, repo=None, deportes_repo=None):
        self._repo = repo or CanchasRepo()
        self._deportes = deportes_repo or DeportesRepo()

    def listar(self, filtros, limite, offset):
        """Sin filtros se incluyen tanto las canchas activas como las inactivas."""
        return self._repo.listar(filtros, limite, offset)

    def obtener(self, id_cancha):
        cancha = self._repo.obtener_por_id(id_cancha)
        if cancha is None:
            raise ErrorNoEncontrado(
                f"No existe una cancha con id {id_cancha}",
                description=f"La cancha {id_cancha} no esta registrada en el club",
            )
        return cancha

    def crear(self, datos):
        faltantes = [campo for campo in CAMPOS_OBLIGATORIOS if campo not in datos]
        if faltantes:
            lista = ", ".join(f"'{campo}'" for campo in faltantes)
            raise ErrorValidacion(
                "Faltan campos obligatorios para crear una cancha",
                description=f"Campos obligatorios ausentes: {lista}",
            )

        nombre = cadena_no_vacia(datos["nombre"], "nombre")
        id_deporte = entero_positivo(datos["id_deporte"], "id_deporte")
        precio_hora = self._validar_precio(datos["precio_hora"])

        techada = self._validar_booleano(
            datos.get("techada"), "techada", TECHADA_POR_DEFECTO
        )
        activa = self._validar_booleano(
            datos.get("activa"), "activa", ACTIVA_POR_DEFECTO
        )

        with transaccion():
            if self._deportes.obtener_por_id(id_deporte) is None:
                raise ErrorNoEncontrado(
                    f"No existe un deporte con id {id_deporte}",
                    description=(
                        f"La cancha debe asociarse a un deporte existente. "
                        f"El deporte {id_deporte} no esta cargado"
                    ),
                )
            return self._repo.crear(nombre, id_deporte, precio_hora, techada, activa)

    def actualizar(self, id_cancha, datos):
        """Los campos omitidos conservan su valor; los presentes se validan como en el alta."""
        cambios = {}

        if "nombre" in datos:
            cambios["nombre"] = cadena_no_vacia(datos["nombre"], "nombre")
        if "precio_hora" in datos:
            cambios["precio_hora"] = self._validar_precio(datos["precio_hora"])
        if "techada" in datos:
            cambios["techada"] = self._validar_booleano(
                datos["techada"], "techada", TECHADA_POR_DEFECTO
            )
        if "activa" in datos:
            cambios["activa"] = self._validar_booleano(
                datos["activa"], "activa", ACTIVA_POR_DEFECTO
            )

        with transaccion():
            self.obtener(id_cancha)
            if not cambios:
                # Nada que escribir, pero el recurso debe existir: se responde 200.
                return self.obtener(id_cancha)
            return self._repo.actualizar(id_cancha, cambios)

    def eliminar(self, id_cancha):
        """No se elimina si tiene reservas asociadas, ni siquiera canceladas: se desactiva."""
        with transaccion():
            self.obtener(id_cancha)

            cantidad = self._repo.contar_reservas(id_cancha)
            if cantidad > 0:
                raise ErrorConflicto(
                    "No se puede eliminar una cancha con reservas asociadas",
                    description=(
                        f"La cancha {id_cancha} tiene {cantidad} reserva(s) "
                        "asociada(s) y no se pueden eliminar. Para dejar de admitir "
                        "nuevas reservas sin perder el historial, desactivala con "
                        "PATCH /canchas/%s {\"activa\": false}" % id_cancha
                    ),
                )

            self._repo.eliminar(id_cancha)

    def listar_disponibles(self, filtros, fecha, hora_inicio, hora_fin, limite, offset):
        """Canchas activas libres en todo el intervalo; consulta informativa que no retiene nada."""
        inicio = datetime.combine(fecha, hora_inicio)
        fin = datetime.combine(fecha, hora_fin)

        # No se exige intervalo futuro: el enunciado no lo pide para esta consulta.
        validar_intervalo(inicio, fin, exigir_futuro=False)

        return self._repo.listar_disponibles(
            filtros, inicio, fin, fecha, hora_inicio, hora_fin, limite, offset
        )

    @staticmethod
    def _validar_precio(valor):
        """El precio es un entero en centavos; los booleanos se rechazan porque True es 1."""
        if isinstance(valor, bool) or not isinstance(valor, int):
            raise ErrorValidacion(
                "El campo 'precio_hora' debe ser un entero positivo",
                description=(
                    f"Se esperaba un entero en centavos, mayor a cero, y se recibio "
                    f"{valor!r}. Los precios se expresan en centavos, por ejemplo "
                    "1000000 representa $10.000,00"
                ),
            )
        if valor < 1:
            raise ErrorValidacion(
                "El campo 'precio_hora' debe ser un entero positivo",
                description=f"Se recibio {valor} y el precio debe ser mayor a cero",
            )
        return valor

    @staticmethod
    def _validar_booleano(valor, campo, por_defecto):
        """Los campos booleanos admiten unicamente true o false."""
        if valor is None:
            return por_defecto
        if not isinstance(valor, bool):
            raise ErrorValidacion(
                f"El campo '{campo}' debe ser true o false",
                description=f"Se recibio {valor!r} en '{campo}'",
            )
        return valor
