"""Los deportes se cargan por script y la API solo los consulta, sin paginacion."""

from ..repos.deportes_repo import DeportesRepo


class DeportesService:
    def __init__(self, repo=None):
        self._repo = repo or DeportesRepo()

    def listar(self):
        return self._repo.listar()
