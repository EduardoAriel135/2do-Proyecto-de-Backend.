"""Reglas de negocio de las reservas recurrentes."""

from datetime import timedelta

from ..db import transaccion
from ..errors import ErrorConflicto, ErrorValidacion
from ..http import entero_positivo
from ..repos.bloqueos_repo import BloqueosRepo
from ..repos.reservas_repo import ReservasRepo
from ..time_utils import (
    calcular_total,
    formatear_instantaneo,
    parsear_instantaneo,
    validar_intervalo,
)
from .canchas_service import CanchasService
from .socios_service import SociosService

CAMPOS_OBLIGATORIOS = (
    "id_socio",
    "id_cancha",
    "fecha_hora_inicio",
    "fecha_hora_fin",
    "cantidad_semanas",
)

# La serie incluye la primera reserva, asi que el minimo son 2 semanas.
CANTIDAD_MINIMA_SEMANAS = 2
CANTIDAD_MAXIMA_SEMANAS = 12


class ReservasRecurrentesService:
    def __init__(
        self,
        repo=None,
        canchas_service=None,
        socios_service=None,
        bloqueos_repo=None,
    ):
        self._repo = repo or ReservasRepo()
        self._canchas = canchas_service or CanchasService()
        self._socios = socios_service or SociosService()
        self._bloqueos = bloqueos_repo or BloqueosRepo()

    def crear(self, datos):
        faltantes = [campo for campo in CAMPOS_OBLIGATORIOS if campo not in datos]
        if faltantes:
            lista = ", ".join(f"'{campo}'" for campo in faltantes)
            raise ErrorValidacion(
                "Faltan campos obligatorios para crear la serie de reservas",
                description=f"Campos obligatorios ausentes: {lista}",
            )

        id_socio = entero_positivo(datos["id_socio"], "id_socio")
        id_cancha = entero_positivo(datos["id_cancha"], "id_cancha")
        cantidad = self._validar_cantidad(datos["cantidad_semanas"])
        inicio_base = parsear_instantaneo(datos["fecha_hora_inicio"], "fecha_hora_inicio")
        fin_base = parsear_instantaneo(datos["fecha_hora_fin"], "fecha_hora_fin")
        horas = validar_intervalo(inicio_base, fin_base, exigir_futuro=True)

        # Serie semanal: mismo horario y duracion, desplazados siete dias.
        fechas = [
            (inicio_base + timedelta(weeks=semana), fin_base + timedelta(weeks=semana))
            for semana in range(cantidad)
        ]

        with transaccion():
            self._verificar_socio(id_socio)
            cancha = self._verificar_cancha(id_cancha)

            conflictos = self._detectar_conflictos(id_socio, id_cancha, fechas)
            if conflictos:
                fechas_conflicto = [
                    formatear_instantaneo(inicio)[:10] for inicio, _ in conflictos
                ]
                raise ErrorConflicto(
                    "La serie de reservas tiene fechas en conflicto",
                    description=(
                        f"No se guardo ninguna reserva. Hay conflicto en "
                        f"{len(conflictos)} de las {cantidad} fechas solicitadas. "
                        "Cancela las reservas existentes o elegi otra franja"
                    ),
                    codigo="ERROR_SERIE_EN_CONFLICTO",
                    # "conflictos" va al mismo nivel que "errors" en el contrato.
                    datos_extra={"conflictos": fechas_conflicto},
                )

            precio_hora = cancha["precio_hora"]
            precio_total = calcular_total(precio_hora, horas)
            a_insertar = [
                (id_socio, id_cancha, inicio, fin, precio_hora, precio_total)
                for inicio, fin in fechas
            ]

            # Todo comparte transaccion: si una insercion falla, no queda la serie a medias.
            ids = self._repo.crear_varias(a_insertar)
            return [self._repo.obtener_por_id(id_reserva) for id_reserva in ids]

    def _detectar_conflictos(self, id_socio, id_cancha, fechas):
        """Revisa cada fecha por separado: la serie entra completa o no entra ninguna."""
        conflictos = []
        for inicio, fin in fechas:
            paso = self._repo.detectar_conflictos(id_socio, id_cancha, inicio, fin)
            # Un bloqueo impide reservar igual que una reserva: la serie tampoco puede ocuparlo.
            en_bloqueo = self._bloqueos.existe_bloqueo_superpuesto(
                id_cancha, inicio.date(), inicio.time().strftime("%H:%M:%S"),
                fin.time().strftime("%H:%M:%S"),
            )
            if paso["en_cancha"] or paso["en_socio"] or en_bloqueo:
                conflictos.append((inicio, fin))
        return conflictos

    def _verificar_socio(self, id_socio):
        socio = self._socios.obtener(id_socio)
        if not socio["activo"]:
            raise ErrorConflicto(
                "El socio no esta activo",
                description=(
                    f"El socio {id_socio} esta inactivo y no puede realizar nuevas "
                    "reservas"
                ),
            )

    def _verificar_cancha(self, id_cancha):
        cancha = self._canchas.obtener(id_cancha)
        if not cancha["activa"]:
            raise ErrorConflicto(
                "La cancha no esta activa",
                description=(
                    f"La cancha {id_cancha} esta inactiva y no admite nuevas reservas"
                ),
            )
        return cancha

    @staticmethod
    def _validar_cantidad(valor):
        """La cantidad de semanas incluye la primera y va de 2 a 12."""
        if isinstance(valor, bool) or not isinstance(valor, int):
            raise ErrorValidacion(
                "El campo 'cantidad_semanas' debe ser un entero",
                description=f"Se recibio {valor!r} en 'cantidad_semanas'",
            )
        if valor < CANTIDAD_MINIMA_SEMANAS or valor > CANTIDAD_MAXIMA_SEMANAS:
            raise ErrorValidacion(
                "La cantidad de semanas esta fuera del rango permitido",
                description=(
                    f"'cantidad_semanas' es {valor} y el rango permitido es de "
                    f"{CANTIDAD_MINIMA_SEMANAS} a {CANTIDAD_MAXIMA_SEMANAS}, "
                    "contando la primera"
                ),
            )
        return valor
