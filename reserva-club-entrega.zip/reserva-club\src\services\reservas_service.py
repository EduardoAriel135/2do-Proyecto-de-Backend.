﻿"""Reglas de negocio de las reservas."""

from ..config import ESTADO_CANCELADA, ESTADO_CONFIRMADA, ESTADO_FINALIZADA, ESTADOS_RESERVA
from ..db import transaccion
from ..errors import (
    ErrorConflicto,
    ErrorNoEncontrado,
    ErrorSuperposicion,
    ErrorValidacion,
)
from ..http import entero_positivo
from ..repos.bloqueos_repo import BloqueosRepo
from ..repos.canchas_repo import CanchasRepo
from ..repos.reservas_repo import ReservasRepo
from ..repos.socios_repo import SociosRepo
from ..time_utils import (
    ahora_del_club,
    calcular_total,
    formatear_instantaneo,
    parsear_instantaneo,
    validar_intervalo,
)

CAMPOS_OBLIGATORIOS = ("id_socio", "id_cancha", "fecha_hora_inicio", "fecha_hora_fin")

# Transiciones permitidas, con la condicion temporal que las habilita.
TRANSICIONES = {
    ESTADO_CONFIRMADA: (ESTADO_CANCELADA, ESTADO_FINALIZADA),
    ESTADO_CANCELADA: (),
    ESTADO_FINALIZADA: (),
}


class ReservasService:
    def __init__(self, repo=None, canchas_repo=None, socios_repo=None,
                 bloqueos_repo=None):
        self._repo = repo or ReservasRepo()
        self._canchas = canchas_repo or CanchasRepo()
        self._socios = socios_repo or SociosRepo()
        self._bloqueos = bloqueos_repo or BloqueosRepo()

    def listar(self, filtros, limite, offset):
        """Se permiten consultar reservas pasadas."""
        return self._repo.listar(filtros, limite, offset)

    def obtener(self, id_reserva):
        reserva = self._repo.obtener_por_id(id_reserva)
        if reserva is None:
            raise ErrorNoEncontrado(
                f"No existe una reserva con id {id_reserva}",
                description=f"La reserva {id_reserva} no esta registrada",
            )
        return reserva

    def crear(self, datos):
        faltantes = [campo for campo in CAMPOS_OBLIGATORIOS if campo not in datos]
        if faltantes:
            lista = ", ".join(f"'{campo}'" for campo in faltantes)
            raise ErrorValidacion(
                "Faltan campos obligatorios para crear una reserva",
                description=f"Campos obligatorios ausentes: {lista}",
            )

        id_socio = entero_positivo(datos["id_socio"], "id_socio")
        id_cancha = entero_positivo(datos["id_cancha"], "id_cancha")
        inicio = parsear_instantaneo(datos["fecha_hora_inicio"], "fecha_hora_inicio")
        fin = parsear_instantaneo(datos["fecha_hora_fin"], "fecha_hora_fin")

        # Se valida el intervalo antes de abrir la transaccion de escritura.
        horas = validar_intervalo(inicio, fin, exigir_futuro=True)

        with transaccion():
            self._verificar_socio(id_socio)
            cancha = self._verificar_cancha(id_cancha)
            self._verificar_bloqueo(id_cancha, inicio, fin)
            self._verificar_superposiciones(id_socio, id_cancha, inicio, fin)

            # La tarifa vigente se copia: cambiar luego el precio no altera esta reserva.
            precio_hora = cancha["precio_hora"]
            precio_total = calcular_total(precio_hora, horas)

            return self._repo.crear(id_socio, id_cancha, inicio, fin, precio_hora,
                                    precio_total)

    def cambiar_estado(self, id_reserva, datos):
        """Repetir el estado actual devuelve exito sin modificar la reserva."""
        if "estado" not in datos:
            raise ErrorValidacion(
                "Falta el campo obligatorio 'estado'",
                description="El cuerpo debe enviar el nuevo estado de la reserva",
            )

        solicitado = datos["estado"]
        if not isinstance(solicitado, str) or solicitado not in ESTADOS_RESERVA:
            raise ErrorValidacion(
                "El estado solicitado no es valido",
                description=(
                    f"'{solicitado!r}' no es un estado conocido. Los estados validos "
                    f"son: {', '.join(ESTADOS_RESERVA)}"
                ),
            )

        with transaccion():
            reserva = self.obtener(id_reserva)
            actual = reserva["estado"]

            if solicitado == actual:
                # Idempotencia: el enunciado pide exito sin modificar nada.
                return reserva

            permitted = TRANSICIONES.get(actual, ())
            if solicitado not in permitted:
                raise ErrorConflicto(
                    f"No se puede pasar de '{actual}' a '{solicitado}'",
                    description=(
                        f"La reserva {id_reserva} esta en estado '{actual}'. Las "
                        f"transiciones permitidas desde '{actual}' son: "
                        f"{', '.join(permitted) if permitted else 'ninguna'}. "
                        "Una reserva cancelada o finalizada es un estado terminal"
                    ),
                )

            if solicitado == ESTADO_CANCELADA:
                self._exigir_inicio_no_alcanzado(reserva, "cancelar")
            elif solicitado == ESTADO_FINALIZADA:
                self._exigir_fin_alcanzado(reserva, "finalizar")

            return self._repo.actualizar_estado(id_reserva, solicitado)

    @staticmethod
    def _exigir_inicio_no_alcanzado(reserva, accion):
        """Cancelar solo se permite mientras no haya llegado el horario de inicio."""
        ahora = ahora_del_club()
        if ahora >= _instante_inicio(reserva):
            raise ErrorConflicto(
                f"No se puede {accion} una reserva cuyo inicio ya paso",
                description=(
                    f"La reserva comienza el {_instante_inicio(reserva)} y el momento "
                    f"actual del club es {formatear_instantaneo(ahora)}. La "
                    "cancelacion solo esta disponible antes de que empiece la reserva"
                ),
            )

    @staticmethod
    def _exigir_fin_alcanzado(reserva, accion):
        """Finalizar solo se permite al alcanzar o superar el horario de fin."""
        ahora = ahora_del_club()
        if ahora < _instante_fin(reserva):
            raise ErrorConflicto(
                f"No se puede {accion} una reserva que todavia no termino",
                description=(
                    f"La reserva termina el {_instante_fin(reserva)} y el momento actual "
                    f"del club es {formatear_instantaneo(ahora)}. La finalizacion solo "
                    "esta disponible al alcanzar o superar el horario de fin"
                ),
            )

    def _verificar_socio(self, id_socio):
        socio = self._socios.obtener_por_id(id_socio)
        if socio is None:
            raise ErrorNoEncontrado(
                f"No existe un socio con id {id_socio}",
                description=f"El socio {id_socio} no esta registrado en el club",
            )
        if not socio["activo"]:
            raise ErrorConflicto(
                "El socio no esta activo",
                description=(
                    f"El socio {id_socio} esta inactivo y no puede realizar nuevas "
                    "reservas"
                ),
            )

    def _verificar_cancha(self, id_cancha):
        cancha = self._canchas.obtener_por_id(id_cancha)
        if cancha is None:
            raise ErrorNoEncontrado(
                f"No existe una cancha con id {id_cancha}",
                description=f"La cancha {id_cancha} no esta registrada en el club",
            )
        if not cancha["activa"]:
            raise ErrorConflicto(
                "La cancha no esta activa",
                description=(
                    f"La cancha {id_cancha} esta inactiva y no admite nuevas reservas"
                ),
            )
        return cancha

    def _verificar_bloqueo(self, id_cancha, inicio, fin):
        """Un bloqueo de mantenimiento impide reservar durante su intervalo."""
        if self._bloqueos.existe_bloqueo_superpuesto(
            id_cancha, inicio.date(), inicio.time(), fin.time()
        ):
            raise ErrorConflicto(
                "La cancha esta bloqueada por mantenimiento",
                description=(
                    f"Existe un bloqueo de mantenimiento sobre la cancha {id_cancha} "
                    f"que se superpone con el intervalo solicitado "
                    f"({inicio.strftime('%H:%M')} a {fin.strftime('%H:%M')})"
                ),
            )

    def _verificar_superposiciones(self, id_socio, id_cancha, inicio, fin):
        """Comprueba las superposiciones de cancha y de socio, y responde 409 con el detalle."""
        conflictos = self._repo.detectar_conflictos(id_socio, id_cancha, inicio, fin)
        if not conflictos["en_cancha"] and not conflictos["en_socio"]:
            return

        motivos = []
        if conflictos["en_cancha"]:
            motivos.append(f"la cancha {id_cancha} ya esta reservada")
        if conflictos["en_socio"]:
            motivos.append(f"el socio {id_socio} ya tiene una reserva")
        razon = " y ademas ".join(motivos)

        detalle = "; ".join(
            f"reserva {reserva['id']} de "
            f"{reserva['fecha_hora_inicio']} a {reserva['fecha_hora_fin']}"
            for reserva in conflictos["reservas"]
        )

        raise ErrorSuperposicion(
            f"El intervalo se superpone con {conflictos['total']} reserva(s) confirmada(s)",
            description=(
                f"No se puede crear la reserva porque {razon} en ese horario. "
                f"Intervalos en conflicto: {detalle}. Dos intervalos son "
                "consecutivos si uno termina exactamente cuando empieza el otro"
            ),
        )


def _instante_inicio(reserva):
    """Extrae el instante de inicio de una reserva ya serializada."""
    return parsear_instantaneo(reserva["fecha_hora_inicio"], "fecha_hora_inicio")


def _instante_fin(reserva):
    """Extrae el instante de fin de una reserva ya serializada."""
    return parsear_instantaneo(reserva["fecha_hora_fin"], "fecha_hora_fin")
