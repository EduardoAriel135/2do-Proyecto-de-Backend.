"""Reglas de negocio de los socios."""

from ..db import transaccion
from ..errors import ErrorConflicto, ErrorNoEncontrado, ErrorValidacion
from ..http import cadena_no_vacia, normalizar_email
from ..repos.socios_repo import SociosRepo

CAMPOS_ALTA = ("nombre", "email")
CAMPOS_EDITABLES = ("nombre", "email", "activo")

# El servidor siempre da de alta a un socio activo.
ACTIVO_POR_DEFECTO = True


class SociosService:
    def __init__(self, repo=None):
        self._repo = repo or SociosRepo()

    def listar(self, filtros, limite, offset):
        return self._repo.listar(filtros, limite, offset)

    def obtener(self, id_socio):
        socio = self._repo.obtener_por_id(id_socio)
        if socio is None:
            raise ErrorNoEncontrado(
                f"No existe un socio con id {id_socio}",
                description=f"El socio {id_socio} no esta registrado en el club",
            )
        return socio

    def crear(self, datos):
        faltantes = [campo for campo in CAMPOS_ALTA if campo not in datos]
        if faltantes:
            raise self._error_obligatorios(faltantes, "socio")

        nombre = cadena_no_vacia(datos["nombre"], "nombre")
        email = normalizar_email(datos["email"], "email")

        with transaccion():
            # El indice UNIQUE de la tabla sigue siendo la garantia real contra carreras.
            if self._repo.obtener_por_email(email) is not None:
                raise self._error_email_duplicado(email)

            return self._repo.crear(nombre, email, ACTIVO_POR_DEFECTO)

    def actualizar(self, id_socio, datos):
        cambios = self._validar_cambios(datos, id_socio)

        with transaccion():
            if cambios:
                self.obtener(id_socio)
                if "email" in cambios:
                    self._verificar_email_disponible(cambios["email"], id_socio)
                return self._repo.actualizar(id_socio, cambios)

            # Sin cambios el recurso debe existir igual, para responder 404 y no 200.
            return self.obtener(id_socio)

    def _validar_cambios(self, datos, id_socio):
        """Valida el cuerpo del PATCH y devuelve solo los campos presentes."""
        cambios = {}

        if "nombre" in datos:
            cambios["nombre"] = cadena_no_vacia(datos["nombre"], "nombre")

        if "email" in datos:
            cambios["email"] = normalizar_email(datos["email"], "email")

        if "activo" in datos:
            if not isinstance(datos["activo"], bool):
                raise ErrorValidacion(
                    "El campo 'activo' debe ser true o false",
                    description=f"Se recibio {datos['activo']!r} en 'activo'",
                )
            cambios["activo"] = datos["activo"]

        return cambios

    def _verificar_email_disponible(self, email, id_socio):
        """Rechaza el cambio si el correo ya pertenece a otro socio, no a este mismo."""
        existente = self._repo.obtener_por_email(email)
        if existente is not None and existente["id"] != id_socio:
            raise self._error_email_duplicado(email)

    def _error_email_duplicado(self, email):
        return ErrorConflicto(
            "El correo electronico ya esta registrado",
            description=(
                f"Ya existe un socio con el correo '{email}'. El correo es unico "
                "tambien entre socios inactivos"
            ),
        )

    @staticmethod
    def _error_obligatorios(faltantes, entidad):
        lista = ", ".join(f"'{campo}'" for campo in faltantes)
        return ErrorValidacion(
            f"Faltan campos obligatorios para crear un {entidad}",
            description=f"Campos obligatorios ausentes: {lista}",
        )
