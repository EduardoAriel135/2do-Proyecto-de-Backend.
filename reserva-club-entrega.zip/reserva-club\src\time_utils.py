"""Fechas y horarios del club, en ISO 8601 con desplazamiento fijo GMT-3."""

import re
from datetime import date, datetime, time, timedelta, timezone

from .config import (
    DURACION_MAXIMA_HORAS,
    DURACION_MINIMA_HORAS,
    HORA_APERTURA,
    HORA_CIERRE,
    UTC_OFFSET_HORAS,
)
from .errors import ErrorValidacion

# Offset fijo a proposito: el enunciado pide GMT-3 sin horario de verano ni conversiones.
UTC_CLUB = timezone(timedelta(hours=UTC_OFFSET_HORAS), name="GMT-3")

PATRON_INSTANTANEO = re.compile(
    r"^(?P<anio>\d{4})-(?P<mes>\d{2})-(?P<dia>\d{2})"
    r"T(?P<hora>\d{2}):(?P<minuto>\d{2}):(?P<segundo>\d{2})"
    r"\.(?P<fraccion>\d{6})"
    r"(?P<desplazamiento>[+-]\d{2}:\d{2})$"
)

PATRON_FECHA = re.compile(r"^\d{4}-\d{2}-\d{2}$")
PATRON_HORA = re.compile(r"^([01]\d|2[0-3]):([0-5]\d):([0-5]\d)$")

HORA_APERTURA_TIME = time(*HORA_APERTURA)
HORA_CIERRE_TIME = time(*HORA_CIERRE)


def ahora_utc():
    """Instante actual real, con zona horaria. Se usa solo como referencia."""
    return datetime.now(timezone.utc)


def ahora_del_club():
    """Momento actual expresado como hora local del club (GMT-3), sin zona."""
    return datetime.now(UTC_CLUB).replace(tzinfo=None)


def formatear_instantaneo(valor):
    """Serializa un datetime naive de hora de club al formato de la API."""
    return valor.strftime("%Y-%m-%dT%H:%M:%S.%f") + "-03:00"


def parsear_instantaneo(valor, campo):
    """Instante ISO 8601 con offset -03:00 y 6 digitos de fraccion, como datetime naive."""
    if not isinstance(valor, str):
        raise ErrorValidacion(
            f"El campo '{campo}' debe ser una cadena de texto",
            description=f"Se recibio {type(valor).__name__} en '{campo}'",
        )

    coincidencia = PATRON_INSTANTANEO.match(valor)
    if not coincidencia:
        raise ErrorValidacion(
            f"El campo '{campo}' tiene un formato invalido",
            description=(
                f"'{valor}' no cumple el formato ISO 8601 con desplazamiento fijo "
                "GMT-3, se espera YYYY-MM-DDTHH:MM:SS.ffffff-03:00 "
                "(6 digitos de fraccion de segundo)"
            ),
        )

    if coincidencia.group("desplazamiento") != "-03:00":
        raise ErrorValidacion(
            f"El campo '{campo}' debe usar el desplazamiento fijo GMT-3",
            description=(
                f"Se recibio el desplazamiento {coincidencia.group('desplazamiento')}. "
                "El enunciado exige el desplazamiento fijo GMT-3 (-03:00) y los "
                "valores no se convierten de zona horaria"
            ),
        )

    try:
        return datetime(
            int(coincidencia.group("anio")),
            int(coincidencia.group("mes")),
            int(coincidencia.group("dia")),
            int(coincidencia.group("hora")),
            int(coincidencia.group("minuto")),
            int(coincidencia.group("segundo")),
            int(coincidencia.group("fraccion")),
        )
    except ValueError as exc:
        raise ErrorValidacion(
            f"El campo '{campo}' no representa una fecha valida",
            description=str(exc),
        ) from exc


def parsear_fecha(valor, campo):
    """Parsea una fecha YYYY-MM-DD."""
    if not isinstance(valor, str) or not PATRON_FECHA.match(valor):
        raise ErrorValidacion(
            f"El campo '{campo}' tiene un formato invalido",
            description=f"Se espera una fecha con formato YYYY-MM-DD, se recibio: {valor!r}",
        )
    try:
        return date.fromisoformat(valor)
    except ValueError as exc:
        raise ErrorValidacion(
            f"El campo '{campo}' no representa una fecha valida",
            description=f"'{valor}' no existe en el calendario: {exc}",
        ) from exc


def parsear_hora(valor, campo):
    """Parsea una hora HH:MM:SS."""
    if not isinstance(valor, str) or not PATRON_HORA.match(valor):
        raise ErrorValidacion(
            f"El campo '{campo}' tiene un formato invalido",
            description=f"Se espera una hora con formato HH:MM:SS, se recibio: {valor!r}",
        )
    return time.fromisoformat(valor)


def validar_horas_en_punto(valor, campo):
    """Las reservas y bloqueos arrancan y terminan en horas en punto."""
    if valor.minute != 0 or valor.second != 0 or valor.microsecond != 0:
        raise ErrorValidacion(
            f"El campo '{campo}' debe ser una hora en punto",
            description=(
                f"'{campo}' es {valor.strftime('%H:%M:%S')}. Las reservas solo pueden "
                "comenzar y terminar en horas en punto"
            ),
        )


def validar_horario_del_club(inicio, fin):
    """El intervalo completo debe caer dentro del horario de atencion."""
    if inicio.timetz().replace(tzinfo=None) < HORA_APERTURA_TIME:
        raise ErrorValidacion(
            "El inicio esta fuera del horario del club",
            description=(
                f"El club atiende de {HORA_APERTURA_TIME.strftime('%H:%M')} a "
                f"{HORA_CIERRE_TIME.strftime('%H:%M')}. "
                f"El inicio {inicio.strftime('%H:%M')} es anterior a la apertura"
            ),
        )
    if fin.timetz().replace(tzinfo=None) > HORA_CIERRE_TIME:
        raise ErrorValidacion(
            "El fin esta fuera del horario del club",
            description=(
                f"El club cierra a las {HORA_CIERRE_TIME.strftime('%H:%M')}. "
                f"El fin {fin.strftime('%H:%M')} es posterior al cierre"
            ),
        )


def calcular_duracion_horas(inicio, fin):
    """Duracion en horas, que por las reglas del club es un entero exacto."""
    return (fin - inicio).total_seconds() / 3600


def validar_duracion(inicio, fin, duracion_minima=DURACION_MINIMA_HORAS,
                     duracion_maxima=DURACION_MAXIMA_HORAS):
    """Valida que la reserva dure entre 1 y 3 horas completas; el maximo se puede ampliar."""
    horas = calcular_duracion_horas(inicio, fin)
    if not horas.is_integer():
        raise ErrorValidacion(
            "La duracion debe ser una cantidad de horas completas",
            description=(
                f"El intervalo de {inicio.strftime('%H:%M')} a {fin.strftime('%H:%M')} "
                f"dura {horas:g} horas. Las horas deben ser enteras"
            ),
        )
    if horas < duracion_minima or horas > duracion_maxima:
        raise ErrorValidacion(
            "La duracion esta fuera del rango permitido",
            description=(
                f"La reserva dura {int(horas)} hora(s) y el rango permitido es de "
                f"{duracion_minima} a {duracion_maxima} horas"
            ),
        )
    return int(horas)


def validar_intervalo(inicio, fin, exigir_futuro=True):
    """Aplica las reglas temporales y devuelve la duracion; `exigir_futuro` se omite en /canchas/disponibles."""
    if inicio >= fin:
        raise ErrorValidacion(
            "El intervalo de la reserva es invalido",
            description=(
                f"Se requiere fecha_hora_inicio < fecha_hora_fin. "
                f"Se recibio inicio {inicio.isoformat()} y fin {fin.isoformat()}"
            ),
        )

    if inicio.date() != fin.date():
        raise ErrorValidacion(
            "La reserva no puede atravesar la medianoche",
            description=(
                f"El inicio ({inicio.date()}) y el fin ({fin.date()}) pertenecen a dias "
                "distintos. El club no permite reservas que crucen el dia"
            ),
        )

    validar_horas_en_punto(inicio, "fecha_hora_inicio")
    validar_horas_en_punto(fin, "fecha_hora_fin")
    validar_horario_del_club(inicio, fin)
    duracion = validar_duracion(inicio, fin)

    if exigir_futuro and inicio <= ahora_del_club():
        raise ErrorValidacion(
            "No se pueden crear reservas en fechas u horarios pasados",
            description=(
                f"El inicio solicitado es {formatear_instantaneo(inicio)} y el momento "
                f"actual del club es {formatear_instantaneo(ahora_del_club())}. "
                "Solo se admiten reservas con inicio posterior al momento actual"
            ),
        )

    return duracion


def calcular_total(precio_hora, horas):
    """Importe total en centavos: horas enteras por la tarifa vigente."""
    return int(precio_hora) * int(horas)
