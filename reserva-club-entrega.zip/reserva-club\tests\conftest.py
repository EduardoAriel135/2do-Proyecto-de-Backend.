"""Fixtures de la suite: cada test corre sobre una base SQLite nueva."""

import sqlite3
from datetime import date, datetime, time, timedelta
from pathlib import Path

import pytest

from src import crear_app

RAIZ = Path(__file__).resolve().parent.parent
ESQUEMA_SQLITE = Path(__file__).resolve().parent / "esquema_sqlite.sql"

# El enunciado obliga a una fecha futura, asi que se usan dias que aun no llegaron.
DIAS_FUTURO = 30


class ConfigTest:
    """Configuracion de la app durante los tests."""

    TESTING = True
    DEBUG = False
    DB_ENGINE = "sqlite"
    DB_SQLITE_PATH = None  # lo completa el fixture `app`


def _crear_base(ruta):
    """Crea el archivo SQLite y le aplica el esquema."""
    conexion = sqlite3.connect(str(ruta))
    try:
        conexion.executescript(ESQUEMA_SQLITE.read_text(encoding="utf-8"))
        conexion.commit()
    finally:
        conexion.close()


@pytest.fixture
def ruta_base(tmp_path):
    """Archivo de base de datos nuevo para cada test."""
    ruta = tmp_path / "club_test.sqlite3"
    _crear_base(ruta)
    return ruta


@pytest.fixture
def app(ruta_base):
    """Aplicacion Flask aislada, apuntando a la base temporal."""
    # Una subclase por test para que la ruta de la base no se comparta.
    configuracion = type(
        "ConfigTestDelTest", (ConfigTest,), {"DB_SQLITE_PATH": str(ruta_base)}
    )
    return crear_app(configuracion)


@pytest.fixture
def cliente(app):
    """Cliente de pruebas."""
    return app.test_client()


@pytest.fixture
def futuro():
    """Construye instantes en el formato ISO 8601 con GMT-3 que espera la API."""

    def construir(dias=DIAS_FUTURO, hora="18:00", minuto=0):
        dia = date.today() + timedelta(days=dias)
        momento = datetime.combine(dia, time(int(hora[:2]), int(hora[3:5]), minuto))
        return momento.strftime("%Y-%m-%dT%H:%M:%S.%f") + "-03:00"

    return construir


@pytest.fixture
def fecha_futura():
    """Devuelve una funcion que construye una fecha futura en formato YYYY-MM-DD."""

    def construir(dias=DIAS_FUTURO):
        return (date.today() + timedelta(days=dias)).isoformat()

    return construir


@pytest.fixture
def hoy_futuro():
    """Fecha de manana, que siempre es futura a efectos de las pruebas."""
    return (date.today() + timedelta(days=1)).isoformat()


@pytest.fixture
def ayer():
    """Datetime naive de ayer a las 10:00, ya transcurrido."""
    return datetime.combine(date.today() - timedelta(days=1), time(10, 0))


@pytest.fixture
def reservar_directamente(app):
    """Inserta una reserva saltandose la API, incluso en el pasado."""
    from src.db import transaccion

    def insertar(
        id_socio,
        id_cancha,
        inicio,
        fin,
        estado="confirmada",
        precio_hora=1000000,
        precio_total=None,
    ):
        if precio_total is None:
            precio_total = precio_hora * int((fin - inicio).total_seconds() // 3600)
        # La conexion se cachea en el contexto, asi que hace falta abrirlo para
        # escribir fuera de una peticion.
        with app.app_context():
            with transaccion() as conexion:
                return conexion.insertar(
                    "INSERT INTO reservas (id_socio, id_cancha, fecha_hora_inicio, "
                    "fecha_hora_fin, estado, precio_hora, precio_total) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    (
                        id_socio,
                        id_cancha,
                        inicio,
                        fin,
                        estado,
                        precio_hora,
                        precio_total,
                    ),
                )

    return insertar


@pytest.fixture
def socio(cliente):
    """Crea un socio activo y devuelve su id."""
    respuesta = cliente.post(
        "/socios",
        json={"nombre": "Ana Gomez", "email": "ana@example.com"},
    )
    assert respuesta.status_code == 201, respuesta.get_json()
    return respuesta.get_json()["id"]


@pytest.fixture
def socio_otro(cliente):
    """Crea un segundo socio activo, para probar el conflicto de agenda."""
    respuesta = cliente.post(
        "/socios",
        json={"nombre": "Bruno Diaz", "email": "bruno@example.com"},
    )
    assert respuesta.status_code == 201, respuesta.get_json()
    return respuesta.get_json()["id"]


@pytest.fixture
def cancha(cliente):
    """Crea una cancha activa del deporte Futbol y devuelve su id."""
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "Cancha Test", "id_deporte": 1, "precio_hora": 1000000},
    )
    assert respuesta.status_code == 201, respuesta.get_json()
    return respuesta.get_json()["id"]


@pytest.fixture
def cancha_otra(cliente):
    """Crea una segunda cancha, para probar que el conflicto de socio no depende."""
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "Cancha Test 2", "id_deporte": 1, "precio_hora": 1500000},
    )
    assert respuesta.status_code == 201, respuesta.get_json()
    return respuesta.get_json()["id"]


@pytest.fixture
def id_deporte_futbol():
    """Id del deporte Futbol, precargado por el script de esquema."""
    return 1
