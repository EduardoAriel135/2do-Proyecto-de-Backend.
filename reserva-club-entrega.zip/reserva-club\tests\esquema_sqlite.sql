-- ============================================================================
--  Esquema equivalente en SQLite, solo para la suite de tests.
--
--  No es el entregable: la aplicacion corre sobre MySQL y el esquema oficial
--  es sql/init_db.sql. Este archivo existe unicamente para poder ejecutar
--  `pytest` en una maquina sin un servidor de base de datos instalado.
--
--  Mantiene las mismas tablas, columnas, claves foraneas y restricciones, con
--  las diferencias de sintaxis propias de SQLite:
--    * INTEGER PRIMARY KEY AUTOINCREMENT en lugar de INT UNSIGNED AUTO_INCREMENT
--    * TEXT en lugar de DATETIME(6) / DATE / TIME, que SQLite no tipa
--    * CHECK en lugar de los ENUM, que SQLite no soporta
--    * sin AUTO_INCREMENT ni Indices con prefijo de motor
-- ============================================================================

CREATE TABLE deportes (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre  TEXT NOT NULL UNIQUE
);

CREATE TABLE socios (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre  TEXT NOT NULL,
    email   TEXT NOT NULL UNIQUE,
    activo  INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0, 1))
);

CREATE TABLE canchas (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre       TEXT NOT NULL,
    id_deporte   INTEGER NOT NULL REFERENCES deportes (id),
    precio_hora  INTEGER NOT NULL CHECK (precio_hora > 0),
    techada      INTEGER NOT NULL DEFAULT 0 CHECK (techada IN (0, 1)),
    activa       INTEGER NOT NULL DEFAULT 1 CHECK (activa IN (0, 1))
);

--  Las columnas de fecha y hora se declaran como DATETIME / DATE / TIME para
--  que los convertores registrados en src/db.py las devuelvan como objetos de
--  Python y no como texto.
CREATE TABLE reservas (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    id_socio          INTEGER NOT NULL REFERENCES socios (id),
    id_cancha         INTEGER NOT NULL REFERENCES canchas (id),
    fecha_hora_inicio DATETIME NOT NULL,
    fecha_hora_fin    DATETIME NOT NULL,
    estado            TEXT NOT NULL DEFAULT 'confirmada'
                      CHECK (estado IN ('confirmada', 'cancelada', 'finalizada')),
    precio_hora       INTEGER NOT NULL,
    precio_total      INTEGER NOT NULL,
    CHECK (fecha_hora_inicio < fecha_hora_fin),
    CHECK (DATE(fecha_hora_inicio) = DATE(fecha_hora_fin)),
    CHECK (TIME(fecha_hora_inicio) >= '08:00:00'),
    CHECK (TIME(fecha_hora_fin) <= '23:00:00')
);

CREATE TABLE bloqueos (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    id_cancha    INTEGER NOT NULL REFERENCES canchas (id) ON DELETE CASCADE,
    fecha        DATE NOT NULL,
    hora_inicio  TIME NOT NULL,
    hora_fin     TIME NOT NULL,
    motivo       TEXT NOT NULL,
    CHECK (hora_inicio < hora_fin),
    CHECK (hora_inicio >= '08:00:00'),
    CHECK (hora_fin <= '23:00:00')
);

-- Indices que usa la deteccion de superposiciones.
CREATE INDEX idx_reservas_cancha_inicio ON reservas (id_cancha, fecha_hora_inicio, fecha_hora_fin);
CREATE INDEX idx_reservas_socio_inicio ON reservas (id_socio, fecha_hora_inicio, fecha_hora_fin);
CREATE INDEX idx_reservas_inicio       ON reservas (fecha_hora_inicio);
CREATE INDEX idx_canchas_nombre       ON canchas (nombre);
CREATE INDEX idx_socios_nombre        ON socios (nombre);
CREATE INDEX idx_bloqueos_cancha_fecha ON bloqueos (id_cancha, fecha);

-- Deportes precargados, igual que en init_db.sql.
INSERT INTO deportes (nombre) VALUES ('Fútbol'), ('Tenis'), ('Pádel');
