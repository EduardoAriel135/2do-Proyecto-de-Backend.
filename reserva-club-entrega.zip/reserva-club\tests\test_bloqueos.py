"""Pruebas de los bloqueos de mantenimiento (extension opcional)."""


def test_crear_bloqueo_devuelve_201(cliente, cancha, fecha_futura):
    respuesta = cliente.post(
        "/bloqueos",
        json={
            "id_cancha": cancha,
            "fecha": fecha_futura(),
            "hora_inicio": "08:00:00",
            "hora_fin": "12:00:00",
            "motivo": "Mantenimiento de iluminacion",
        },
    )

    assert respuesta.status_code == 201
    bloqueo = respuesta.get_json()
    assert bloqueo["motivo"] == "Mantenimiento de iluminacion"
    assert bloqueo["hora_inicio"] == "08:00:00"


def test_crear_bloqueo_exige_cancha_existente(cliente, fecha_futura):
    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": 9999, "fecha": fecha_futura(),
              "hora_inicio": "08:00:00", "hora_fin": "12:00:00", "motivo": "X"},
    )

    assert respuesta.status_code == 404


def test_bloqueo_puede_durar_toda_la_jornada(cliente, cancha, fecha_futura):
    """A diferencia de una reserva, el bloqueo puede superar las tres horas."""
    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "08:00:00", "hora_fin": "23:00:00", "motivo": "Pintura"},
    )

    assert respuesta.status_code == 201


def test_bloqueo_rechaza_horario_fuera_del_club(cliente, cancha, fecha_futura):
    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "07:00:00", "hora_fin": "12:00:00", "motivo": "X"},
    )

    assert respuesta.status_code == 400


def test_bloqueo_rechaza_hora_no_en_punto(cliente, cancha, fecha_futura):
    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "08:30:00", "hora_fin": "12:00:00", "motivo": "X"},
    )

    assert respuesta.status_code == 400


def test_bloqueo_rechaza_intervalo_invertido(cliente, cancha, fecha_futura):
    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "12:00:00", "hora_fin": "08:00:00", "motivo": "X"},
    )

    assert respuesta.status_code == 400


def test_bloqueo_no_puede_crearse_en_el_pasado(cliente, cancha):
    from datetime import date, timedelta

    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha,
              "fecha": (date.today() - timedelta(days=1)).isoformat(),
              "hora_inicio": "08:00:00", "hora_fin": "12:00:00", "motivo": "X"},
    )

    assert respuesta.status_code == 400


def test_bloqueo_no_puede_superponerse_con_una_reserva_confirmada(
    cliente, socio, cancha, futuro, fecha_futura
):
    cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "18:00:00", "hora_fin": "20:00:00", "motivo": "X"},
    )

    assert respuesta.status_code == 409


def test_bloqueo_no_puede_superponerse_con_otro_bloqueo(
    cliente, cancha, fecha_futura
):
    cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "08:00:00", "hora_fin": "12:00:00", "motivo": "Primero"},
    )

    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "10:00:00", "hora_fin": "14:00:00", "motivo": "Segundo"},
    )

    assert respuesta.status_code == 409


def test_un_bloqueo_impide_crear_una_reserva(cliente, socio, cancha, futuro,
                                             fecha_futura):
    cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "18:00:00", "hora_fin": "20:00:00", "motivo": "X"},
    )

    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 409


def test_el_bloqueo_se_considera_en_la_consulta_de_disponibilidad(
    cliente, cancha, cancha_otra, fecha_futura
):
    cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "08:00:00", "hora_fin": "23:00:00", "motivo": "Pintura"},
    )

    cuerpo = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}"
        "&hora_inicio=18:00:00&hora_fin=20:00:00"
    ).get_json()

    ids = [c["id"] for c in cuerpo["canchas"]]
    assert cancha not in ids
    assert cancha_otra in ids


def test_quitar_el_bloqueo_libera_solo_su_restriccion(
    cliente, socio, cancha, futuro, fecha_futura
):
    creado = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "08:00:00", "hora_fin": "23:00:00", "motivo": "Pintura"},
    ).get_json()

    borrado = cliente.delete(f"/bloqueos/{creado['id']}")
    assert borrado.status_code == 204

    reserva = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )
    assert reserva.status_code == 201

    # El bloqueo no desactiva la cancha.
    assert cliente.get(f"/canchas/{cancha}").get_json()["activa"] is True


def test_listar_bloqueos_con_filtros(cliente, cancha, cancha_otra, fecha_futura):
    cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "08:00:00", "hora_fin": "12:00:00", "motivo": "A"},
    )

    por_cancha = cliente.get(f"/bloqueos?id_cancha={cancha}").get_json()["bloqueos"]
    por_fecha = cliente.get(f"/bloqueos?fecha={fecha_futura()}").get_json()["bloqueos"]
    por_otra = cliente.get(f"/bloqueos?id_cancha={cancha_otra}").get_json()["bloqueos"]

    assert len(por_cancha) == 1
    assert len(por_fecha) == 1
    assert por_otra == []


def test_eliminar_bloqueo_inexistente_devuelve_404(cliente):
    assert cliente.delete("/bloqueos/9999").status_code == 404


def test_bloqueo_rechaza_campos_desconocidos(cliente, cancha, fecha_futura):
    respuesta = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": fecha_futura(),
              "hora_inicio": "08:00:00", "hora_fin": "12:00:00",
              "motivo": "X", "reserva_id": 5},
    )

    assert respuesta.status_code == 400
