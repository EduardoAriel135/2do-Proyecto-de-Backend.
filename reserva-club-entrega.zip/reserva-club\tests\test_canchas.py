"""Pruebas de canchas: alta, validaciones, filtros, actualizacion y baja."""


def test_crear_cancha_devuelve_201_con_valores_por_defecto(cliente, id_deporte_futbol):
    """techada false y activa true por defecto, tal como pide el enunciado."""
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "Cancha 1", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000000},
    )

    assert respuesta.status_code == 201
    cancha = respuesta.get_json()
    assert cancha["techada"] is False
    assert cancha["activa"] is True
    assert cancha["precio_hora"] == 1000000


def test_crear_cancha_acepta_los_booleanos_enviados(cliente, id_deporte_futbol):
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "Cancha 2", "id_deporte": id_deporte_futbol,
              "precio_hora": 500000, "techada": True, "activa": False},
    )

    assert respuesta.status_code == 201
    cancha = respuesta.get_json()
    assert cancha["techada"] is True
    assert cancha["activa"] is False


def test_crear_cancha_rechaza_nombre_vacio(cliente, id_deporte_futbol):
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "  ", "id_deporte": id_deporte_futbol, "precio_hora": 100},
    )

    assert respuesta.status_code == 400


def test_crear_cancha_rechaza_deporte_inexistente(cliente):
    respuesta = cliente.post(
        "/canchas", json={"nombre": "Cancha", "id_deporte": 9999, "precio_hora": 100}
    )

    assert respuesta.status_code == 404


def test_crear_cancha_rechaza_precio_cero(cliente, id_deporte_futbol):
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "Cancha", "id_deporte": id_deporte_futbol, "precio_hora": 0},
    )

    assert respuesta.status_code == 400


def test_crear_cancha_rechaza_precio_negativo(cliente, id_deporte_futbol):
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "Cancha", "id_deporte": id_deporte_futbol, "precio_hora": -5},
    )

    assert respuesta.status_code == 400


def test_crear_cancha_rechaza_precio_no_entero(cliente, id_deporte_futbol):
    """Los precios son enteros en centavos, no decimales."""
    respuesta = cliente.post(
        "/canchas",
        json={"nombre": "Cancha", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000.5},
    )

    assert respuesta.status_code == 400


def test_crear_cancha_rechaza_id_deporte_cero(cliente):
    respuesta = cliente.post(
        "/canchas", json={"nombre": "Cancha", "id_deporte": 0, "precio_hora": 100}
    )

    assert respuesta.status_code == 400


def test_obtener_cancha_inexistente_devuelve_404(cliente):
    assert cliente.get("/canchas/9999").status_code == 404


def test_listar_canchas_sin_filtros_trae_activas_e_inactivas(cliente, cancha, id_deporte_futbol):
    inactiva = cliente.post(
        "/canchas",
        json={"nombre": "Cancha Inactiva", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000, "activa": False},
    ).get_json()

    ids = [c["id"] for c in cliente.get("/canchas").get_json()["canchas"]]

    assert cancha in ids
    assert inactiva["id"] in ids


def test_filtrar_canchas_por_activa(cliente, cancha, id_deporte_futbol):
    activa = cancha
    inactiva = cliente.post(
        "/canchas",
        json={"nombre": "Cancha Inactiva", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000, "activa": False},
    ).get_json()["id"]

    activas = [c["id"] for c in cliente.get("/canchas?activa=true").get_json()["canchas"]]
    inactivas = [c["id"] for c in cliente.get("/canchas?activa=false").get_json()["canchas"]]

    assert activas == [activa]
    assert inactivas == [inactiva]


def test_filtrar_canchas_por_nombre_parcial_e_insensible(cliente, cancha):
    respuesta = cliente.get("/canchas?nombre=TEST")

    assert respuesta.status_code == 200
    assert [c["id"] for c in respuesta.get_json()["canchas"]] == [cancha]


def test_filtrar_canchas_por_techada(cliente, id_deporte_futbol):
    techada = cliente.post(
        "/canchas",
        json={"nombre": "Techada", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000, "techada": True},
    ).get_json()["id"]
    cliente.post(
        "/canchas",
        json={"nombre": "Descubierta", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000},
    )

    resultado = cliente.get("/canchas?techada=true").get_json()["canchas"]

    assert [c["id"] for c in resultado] == [techada]


def test_filtrar_canchas_combina_filtros_con_and(cliente, id_deporte_futbol):
    """Los filtros se combinan con AND."""
    no_coincide = cliente.post(
        "/canchas",
        json={"nombre": "Futbol 1", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000, "techada": True, "activa": False},
    ).get_json()["id"]
    coincide = cliente.post(
        "/canchas",
        json={"nombre": "Futbol 1", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000, "techada": True, "activa": True},
    ).get_json()["id"]

    resultado = cliente.get(
        f"/canchas?id_deporte={id_deporte_futbol}&nombre=futbol&techada=true&activa=true"
    ).get_json()["canchas"]

    assert [c["id"] for c in resultado] == [coincide]


def test_actualizar_cancha_devuelve_200_con_el_recurso_actualizado(cliente, cancha):
    respuesta = cliente.patch(f"/canchas/{cancha}", json={"nombre": "Cancha Renombrada"})

    assert respuesta.status_code == 200
    assert respuesta.get_json()["nombre"] == "Cancha Renombrada"


def test_actualizar_cancha_conserva_los_campos_omitidos(cliente, cancha):
    respuesta = cliente.patch(f"/canchas/{cancha}", json={"precio_hora": 2000000})

    actualizado = respuesta.get_json()
    assert actualizado["precio_hora"] == 2000000
    assert actualizado["nombre"] == "Cancha Test"
    assert actualizado["activa"] is True


def test_actualizar_cancha_rechaza_id_deporte(cliente, cancha, id_deporte_futbol):
    """El deporte no se modifica una vez creada la cancha."""
    respuesta = cliente.patch(
        f"/canchas/{cancha}", json={"id_deporte": id_deporte_futbol}
    )

    assert respuesta.status_code == 400
    assert "id_deporte" in respuesta.get_json()["errors"][0]["description"]


def test_actualizar_cancha_rechaza_cuerpo_vacio(cliente, cancha):
    respuesta = cliente.patch(f"/canchas/{cancha}", json={})

    assert respuesta.status_code == 400


def test_actualizar_cancha_inexistente_devuelve_404(cliente):
    assert cliente.patch("/canchas/9999", json={"nombre": "X"}).status_code == 404


def test_desactivar_cancha_con_patch(cliente, cancha):
    """La alternativa recomendada a eliminar cuando hay reservas."""
    respuesta = cliente.patch(f"/canchas/{cancha}", json={"activa": False})

    assert respuesta.status_code == 200
    assert respuesta.get_json()["activa"] is False


def test_eliminar_cancha_sin_reservas_devuelve_204(cliente, cancha):
    respuesta = cliente.delete(f"/canchas/{cancha}")

    assert respuesta.status_code == 204
    assert respuesta.data == b""
    assert cliente.get(f"/canchas/{cancha}").status_code == 404


def test_eliminar_cancha_inexistente_devuelve_404(cliente):
    assert cliente.delete("/canchas/9999").status_code == 404


def test_disponibles_exige_los_tres_parametros(cliente):
    respuesta = cliente.get("/canchas/disponibles?fecha=2030-01-01")

    assert respuesta.status_code == 400
    assert "hora_inicio" in respuesta.get_json()["errors"][0]["description"]


def test_disponibles_rechaza_hora_no_en_punto(cliente, fecha_futura):
    respuesta = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}&hora_inicio=18:30:00&hora_fin=20:00:00"
    )

    assert respuesta.status_code == 400


def test_disponibles_rechaza_intervalo_fuera_del_horario(cliente, fecha_futura):
    """El club atiende de 08:00 a 23:00."""
    respuesta = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}&hora_inicio=07:00:00&hora_fin=09:00:00"
    )

    assert respuesta.status_code == 400


def test_disponibles_rechaza_duracion_de_cuatro_horas(cliente, fecha_futura):
    """Las reservas duran entre una y tres horas."""
    respuesta = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}&hora_inicio=08:00:00&hora_fin=12:00:00"
    )

    assert respuesta.status_code == 400


def test_disponibles_sin_canchas_devuelve_200_con_arreglo_vacio(cliente, fecha_futura):
    """Sin canchas libres se responde 200 con arreglo vacio, nunca 204."""
    respuesta = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}&hora_inicio=18:00:00&hora_fin=20:00:00"
    )

    assert respuesta.status_code == 200
    cuerpo = respuesta.get_json()
    assert cuerpo["canchas"] == []
    assert "_links" in cuerpo


def test_disponibles_devuelve_las_canchas_activas(cliente, cancha, fecha_futura):
    respuesta = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}&hora_inicio=18:00:00&hora_fin=20:00:00"
    )

    assert respuesta.status_code == 200
    assert [c["id"] for c in respuesta.get_json()["canchas"]] == [cancha]


def test_disponibles_excluye_canchas_inactivas(cliente, cancha, fecha_futura):
    cliente.patch(f"/canchas/{cancha}", json={"activa": False})

    respuesta = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}&hora_inicio=18:00:00&hora_fin=20:00:00"
    )

    assert respuesta.get_json()["canchas"] == []


def test_disponibles_filtra_por_deporte_y_techada(cliente, id_deporte_futbol,
                                                   fecha_futura):
    cliente.post(
        "/canchas",
        json={"nombre": "Tenis cubierta", "id_deporte": 2, "precio_hora": 800000,
              "techada": True},
    )
    cliente.post(
        "/canchas",
        json={"nombre": "Futbol abierta", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000000},
    )

    respuesta = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}&hora_inicio=18:00:00"
        f"&hora_fin=20:00:00&techada=true"
    )

    canchas = respuesta.get_json()["canchas"]
    assert [c["nombre"] for c in canchas] == ["Tenis cubierta"]
