"""Pruebas de contrato: swagger.yaml tiene que coincidir con la implementacion."""

from datetime import date, timedelta
from pathlib import Path

import pytest
import yaml

RAIZ = Path(__file__).resolve().parent.parent
ARCHIVO_CONTRATO = RAIZ / "swagger.yaml"


@pytest.fixture(scope="module")
def contrato():
    """Contenido de swagger.yaml ya parseado."""
    return yaml.safe_load(ARCHIVO_CONTRATO.read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def respuestas_contrato(contrato):
    """Mapa (metodo, ruta) -> conjunto de codigos de estado documentados."""
    mapa = {}
    for ruta, operaciones in contrato["paths"].items():
        for metodo, operacion in operaciones.items():
            if metodo in ("get", "post", "patch", "put", "delete"):
                mapa[(metodo.upper(), ruta)] = set(operacion["responses"])
    return mapa


def _ruta_de_flask(app, ruta_contrato, metodo):
    """Traduce una ruta del contrato (con {id}) a la regla real de Flask."""
    for regla in app.url_map.iter_rules():
        if metodo not in regla.methods or str(regla.rule).startswith("/static"):
            continue
        # /canchas/{id} -> /canchas/<int:id_cancha>
        partes_contrato = ruta_contrato.strip("/").split("/")
        if len(partes_contrato) != len(regla.rule.strip("/").split("/")):
            continue
        coincide = True
        for parte, real in zip(partes_contrato, str(regla.rule).strip("/").split("/")):
            if parte.startswith("{"):
                if not (real.startswith("<") and real.endswith(">")):
                    coincide = False
                    break
            elif parte != real:
                coincide = False
                break
        if coincide:
            return str(regla.rule)
    return None


def test_todo_endpoint_implementado_esta_documentado(app, contrato):
    """Ninguna ruta del contrato puede faltar en la aplicacion."""
    faltantes = []
    for (metodo, ruta) in contrato_rutas(contrato):
        if _ruta_de_flask(app, ruta, metodo) is None:
            faltantes.append(f"{metodo} {ruta}")

    assert not faltantes, f"Endpoints del contrato sin implementar: {faltantes}"


def contrato_rutas(contrato):
    for ruta, operaciones in contrato["paths"].items():
        for metodo in operaciones:
            if metodo in ("get", "post", "patch", "put", "delete"):
                yield metodo.upper(), ruta


def test_los_listados_vacios_responden_200_y_no_204(cliente, respuestas_contrato):
    """Un listado sin resultados es 200 con el arreglo vacio, nunca 204."""
    for ruta in ("/deportes", "/canchas", "/socios", "/reservas", "/bloqueos"):
        respuesta = cliente.get(ruta)
        cuerpo = respuesta.get_json()

        assert respuesta.status_code == 200, ruta
        assert cuerpo is not None, f"{ruta} devolvio un cuerpo vacio"
        assert "204" not in respuestas_contrato[("GET", ruta)]


def test_patch_devuelve_200_con_el_recurso(cliente, socio, cancha, respuestas_contrato):
    """Discrepancia corregida: PATCH ya no responde 204."""
    socio_actualizado = cliente.patch(f"/socios/{socio}", json={"nombre": "Ana Gomez Paz"})
    cancha_actualizada = cliente.patch(f"/canchas/{cancha}", json={"nombre": "Cancha Nueva"})

    assert socio_actualizado.status_code == 200
    assert socio_actualizado.get_json()["nombre"] == "Ana Gomez Paz"
    assert cancha_actualizada.status_code == 200
    assert cancha_actualizada.get_json()["nombre"] == "Cancha Nueva"

    assert respuestas_contrato[("PATCH", "/socios/{id}")] == {"200", "400", "404", "409", "500"}
    assert respuestas_contrato[("PATCH", "/canchas/{id}")] == {"200", "400", "404", "500"}


def test_el_cambio_de_estado_devuelve_200_con_la_reserva(cliente, socio, cancha,
                                                         futuro, respuestas_contrato):
    """Discrepancia corregida: PUT /reservas/{id}/estado ya no responde 204."""
    reserva = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    ).get_json()

    respuesta = cliente.put(
        f"/reservas/{reserva['id']}/estado", json={"estado": "cancelada"}
    )

    assert respuesta.status_code == 200
    assert respuesta.get_json()["estado"] == "cancelada"
    assert "200" in respuestas_contrato[("PUT", "/reservas/{id}/estado")]
    assert "204" not in respuestas_contrato[("PUT", "/reservas/{id}/estado")]


def test_las_creaciones_declaran_el_recurso_creado(cliente, socio, cancha, futuro,
                                                   contrato):
    """Los 201 no son genericos: cada Endpoint declara el schema que devuelve."""
    respuestas = contrato["components"]["responses"]
    for nombre in ("CanchaCreated", "SocioCreated", "ReservaCreated",
                   "BloqueoCreated", "ReservasRecurrentesCreated"):
        contenido = respuestas[nombre]["content"]["application/json"]["schema"]
        assert "$ref" in contenido, nombre


def test_el_contrato_declara_una_respuesta_204_por_verbos(contrato):
    """El unico verbo que puede devolver 204 es DELETE."""
    sobrantes = []
    for ruta, operaciones in contrato["paths"].items():
        for metodo, operacion in operaciones.items():
            if metodo in ("get", "post", "patch", "put") and "204" in operacion["responses"]:
                sobrantes.append(f"{metodo.upper()} {ruta}")

    assert not sobrantes, f"Verbos no DELETE con 204: {sobrantes}"


def test_el_contrato_expone_el_filtro_activo_de_socios(contrato):
    """El filtro `activo` separa los dados de baja de los que siguen en el club."""
    nombres = {
        parametro["$ref"].rsplit("/", 1)[-1]
        for parametro in contrato["paths"]["/socios"]["get"]["parameters"]
    }

    assert "ActivoFilter" in nombres
    activo = contrato["components"]["parameters"]["ActivoFilter"]
    assert activo["name"] == "activo"
    assert activo["schema"]["type"] == "boolean"


def test_los_enlaces_de_paginacion_cubren_las_paginas_interiores(contrato):
    """Los enlaces son opcionales: sin _prev en la primera y sin _next en la ultima."""
    enlaces = contrato["components"]["schemas"]["Links"]["properties"]

    assert set(enlaces) == {"_first", "_prev", "_next", "_last"}


def test_el_contrato_incluye_los_extremos_de_paginacion(contrato):
    """_limit y _offset tienen que quedar acotados en el contrato."""
    parametros = contrato["components"]["parameters"]

    assert parametros["Limit"]["name"] == "_limit"
    assert parametros["Limit"]["schema"]["maximum"] == 100
    assert parametros["Offset"]["name"] == "_offset"
    assert parametros["Offset"]["schema"]["minimum"] == 0


def test_todas_las_referencias_del_contrato_existen(contrato):
    """Un $ref roto rompe la carga del contrato en Swagger UI."""
    import re

    texto = ARCHIVO_CONTRATO.read_text(encoding="utf-8")
    componentes = contrato.get("components", {})
    rotos = []
    for seccion, nombre in set(re.findall(r"#/components/(\w+)/(\w+)", texto)):
        if nombre not in componentes.get(seccion, {}):
            rotos.append(f"{seccion}/{nombre}")

    assert not rotos, f"Referencias rotas: {rotos}"


def test_los_endpoints_de_salud_responden_200(cliente, contrato):
    """Los endpoints de diagnostico estan documentados y funcionan."""
    raiz = cliente.get("/")
    assert raiz.status_code == 200
    assert raiz.get_json()["servicio"] == "API de Reservas de Club Deportivo"

    salud = cliente.get("/salud")
    assert salud.status_code == 200
    assert salud.get_json()["estado"] == "ok"

    assert "/" in contrato["paths"]
    assert "/salud" in contrato["paths"]


def test_el_contrato_exige_el_desplazamiento_fijo_de_gmt3(contrato):
    """La API solo acepta -03:00, asi que el contrato tampoco admite otros."""
    reserva = contrato["components"]["schemas"]["ReservaCreate"]["properties"]

    for campo in ("fecha_hora_inicio", "fecha_hora_fin"):
        patron = reserva[campo]["pattern"]
        # Debe cerrar el desplazamiento fijo de GMT-3 y con seis decimales.
        assert patron.endswith("-03:00$"), campo
        assert r"\.\d{6}" in patron, campo


def test_el_contrato_documenta_la_garantia_de_la_serie(contrato):
    """La extension opcional de recurrentes es atomica, y el contrato lo dice."""
    descripcion = contrato["paths"]["/reservas/recurrentes"]["post"]["description"]

    assert "no se guarda ninguna" in descripcion
