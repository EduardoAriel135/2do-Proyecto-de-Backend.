"""Pruebas de deportes: solo lectura, sin paginacion."""


def test_listar_deportes_devuelve_los_precargados(cliente):
    respuesta = cliente.get("/deportes")

    assert respuesta.status_code == 200
    cuerpo = respuesta.get_json()
    assert "deportes" in cuerpo
    nombres = [deporte["nombre"] for deporte in cuerpo["deportes"]]
    assert nombres == ["Fútbol", "Tenis", "Pádel"]


def test_deportes_va_ordenado_por_id(cliente):
    respuesta = cliente.get("/deportes")

    ids = [deporte["id"] for deporte in respuesta.get_json()["deportes"]]
    assert ids == sorted(ids)


def test_deportes_no_lleva_paginacion(cliente):
    """Sin _links porque la consulta no se pagina."""
    respuesta = cliente.get("/deportes")

    assert "_links" not in respuesta.get_json()


def test_deportes_rechaza_parametros_desconocidos(cliente):
    respuesta = cliente.get("/deportes?_limit=5")

    assert respuesta.status_code == 400
    assert respuesta.get_json()["errors"][0]["code"] == "ERROR_VALIDACION"
