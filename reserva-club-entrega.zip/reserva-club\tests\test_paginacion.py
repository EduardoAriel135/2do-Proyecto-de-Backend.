"""Pruebas de paginacion y navegacion HATEOAS.

El enunciado exige filtrar ANTES de paginar: si se paginara primero y se
filtrara despues, una pagina vendria incompleta.
"""

import pytest

RANGO_SOCIOS = 25


@pytest.fixture
def muchos_socios(cliente):
    """Crea 25 socios, suficiente para recorrer varias paginas."""
    ids = []
    for indice in range(RANGO_SOCIOS):
        respuesta = cliente.post(
            "/socios",
            json={"nombre": f"Socio {indice:02d}", "email": f"s{indice}@example.com"},
        )
        assert respuesta.status_code == 201
        ids.append(respuesta.get_json()["id"])
    return ids


def test_limit_por_defecto_es_10(cliente, muchos_socios):
    respuesta = cliente.get("/socios")

    assert len(respuesta.get_json()["socios"]) == 10


def test_limit_se_respeta(cliente, muchos_socios):
    respuesta = cliente.get("/socios?_limit=3")

    assert len(respuesta.get_json()["socios"]) == 3


def test_limit_maximo_es_100(cliente, muchos_socios):
    """_limit esta acotado entre 1 y 100."""
    assert cliente.get("/socios?_limit=100").status_code == 200


def test_limit_cero_produce_400(cliente):
    assert cliente.get("/socios?_limit=0").status_code == 400


def test_limit_mayor_a_100_produce_400(cliente):
    assert cliente.get("/socios?_limit=101").status_code == 400


def test_limit_no_numerico_produce_400(cliente):
    assert cliente.get("/socios?_limit=muchos").status_code == 400


def test_offset_desplaza_los_resultados(cliente, muchos_socios):
    primera = cliente.get("/socios?_limit=5").get_json()["socios"]
    segunda = cliente.get("/socios?_limit=5&_offset=5").get_json()["socios"]

    assert [s["id"] for s in primera] != [s["id"] for s in segunda]


def test_offset_cero_produce_400(cliente):
    assert cliente.get("/socios?_offset=-1").status_code == 400


def test_offset_no_numerico_produce_400(cliente):
    assert cliente.get("/socios?_offset=abc").status_code == 400


def test_offset_mayor_al_total_devuelve_200_con_arreglo_vacio(cliente, muchos_socios):
    """Pasarse del total no es error: 200 con arreglo vacio y sin _next."""
    respuesta = cliente.get("/socios?_offset=500")

    assert respuesta.status_code == 200
    cuerpo = respuesta.get_json()
    assert cuerpo["socios"] == []
    assert cuerpo["_links"]["_next"] is None


def test_los_resultados_vienen_ordenados_por_id_ascendente(cliente, muchos_socios):
    ids = [s["id"] for s in cliente.get("/socios?_limit=25").get_json()["socios"]]

    assert ids == sorted(ids)
    assert ids == muchos_socios


def test_los_listados_incluyen_los_cuatro_enlaces(cliente, muchos_socios):
    enlaces = cliente.get("/socios?_limit=10").get_json()["_links"]

    assert set(enlaces) == {"_first", "_prev", "_next", "_last"}


def test_enlaces_de_la_primera_pagina(cliente, muchos_socios):
    enlaces = cliente.get("/socios?_limit=10").get_json()["_links"]

    assert "_offset=0" in enlaces["_first"]
    assert enlaces["_prev"] is None
    assert "_offset=10" in enlaces["_next"]


def test_enlaces_de_una_pagina_intermedia(cliente, muchos_socios):
    """Con _limit=10 hay tres paginas; la del medio tiene _prev y _next."""
    enlaces = cliente.get("/socios?_limit=10&_offset=10").get_json()["_links"]

    assert "_offset=0" in enlaces["_first"]
    assert "_offset=0" in enlaces["_prev"]
    assert "_offset=20" in enlaces["_next"]
    assert "_offset=20" in enlaces["_last"]


def test_enlaces_de_la_ultima_pagina(cliente, muchos_socios):
    enlaces = cliente.get("/socios?_limit=10&_offset=20").get_json()["_links"]

    assert enlaces["_next"] is None
    assert "_offset=10" in enlaces["_prev"]
    assert "_offset=20" in enlaces["_last"]


def test_los_enlaces_de_ultima_apuntan_a_la_ultima_pagina_real(cliente, muchos_socios):
    ultima = cliente.get("/socios?_limit=10&_offset=20").get_json()["socios"]

    assert len(ultima) == 5


def test_los_enlaces_conservan_los_filtros(cliente, muchos_socios):
    """Navegar con los enlaces no debe perder el filtrado aplicado."""
    cuerpo = cliente.get("/socios?nombre=socio&_limit=5").get_json()

    assert "nombre=socio" in cuerpo["_links"]["_next"]
    assert "_limit=5" in cuerpo["_links"]["_next"]


def test_la_clave_del_listado_es_descriptiva(cliente, socio, cancha):
    assert "socios" in cliente.get("/socios").get_json()
    assert "canchas" in cliente.get("/canchas").get_json()
    assert "deportes" in cliente.get("/deportes").get_json()


def test_el_filtro_se_aplica_antes_de_paginar(cliente, socio, id_deporte_futbol):
    """Con 3 canchas de las que solo 1 cumple, la pagina trae esa y no una vacia."""
    for indice in range(3):
        cliente.post(
            "/canchas",
            json={"nombre": f"Descartada {indice}", "id_deporte": 2,
                  "precio_hora": 1000},
        )
    coincide = cliente.post(
        "/canchas",
        json={"nombre": "La que coincide", "id_deporte": id_deporte_futbol,
              "precio_hora": 1000},
    ).get_json()["id"]

    cuerpo = cliente.get("/canchas?id_deporte=1&_limit=10").get_json()

    assert [c["id"] for c in cuerpo["canchas"]] == [coincide]
    # La ultima pagina es la unica pagina, asi que no hay siguiente.
    assert cuerpo["_links"]["_next"] is None


def test_la_paginacion_tambien_aplica_a_reservas(cliente, socio, cancha, futuro):
    for indice in range(3):
        cliente.post(
            "/reservas",
            json={"id_socio": socio, "id_cancha": cancha,
                  "fecha_hora_inicio": futuro(10 + indice, hora="09:00"),
                  "fecha_hora_fin": futuro(10 + indice, hora="10:00")},
        )

    cuerpo = cliente.get("/reservas?_limit=2").get_json()

    assert len(cuerpo["reservas"]) == 2
    assert "_offset=2" in cuerpo["_links"]["_next"]


def test_la_paginacion_tambien_aplica_a_disponibles(cliente, cancha, fecha_futura):
    cliente.post(
        "/canchas",
        json={"nombre": "Segunda", "id_deporte": 2, "precio_hora": 1000},
    )

    cuerpo = cliente.get(
        f"/canchas/disponibles?fecha={fecha_futura()}"
        "&hora_inicio=18:00:00&hora_fin=20:00:00&_limit=1"
    ).get_json()

    assert len(cuerpo["canchas"]) == 1
    assert cuerpo["_links"]["_next"] is not None
