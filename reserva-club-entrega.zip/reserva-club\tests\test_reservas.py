"""Pruebas de reservas: alta, importe, horarios y superposiciones."""

import pytest


def test_crear_reserva_devuelve_201_en_estado_confirmada(cliente, socio, cancha,
                                                        futuro):
    respuesta = cliente.post(
        "/reservas",
        json={
            "id_socio": socio,
            "id_cancha": cancha,
            "fecha_hora_inicio": futuro(hora="18:00"),
            "fecha_hora_fin": futuro(hora="20:00"),
        },
    )

    assert respuesta.status_code == 201
    reserva = respuesta.get_json()
    assert reserva["estado"] == "confirmada"
    assert reserva["id"] >= 1


def test_calcula_el_importe_para_dos_horas(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={
            "id_socio": socio,
            "id_cancha": cancha,
            "fecha_hora_inicio": futuro(hora="18:00"),
            "fecha_hora_fin": futuro(hora="20:00"),
        },
    )

    reserva = respuesta.get_json()
    assert reserva["precio_hora"] == 1000000
    assert reserva["precio_total"] == 2000000


@pytest.mark.parametrize(
    "hora_inicio,hora_fin,total_esperado",
    [
        ("18:00", "19:00", 1000000),
        ("18:00", "20:00", 2000000),
        ("18:00", "21:00", 3000000),
    ],
)
def test_importe_segun_la_duracion(cliente, socio, cancha, futuro,
                                   hora_inicio, hora_fin, total_esperado):
    respuesta = cliente.post(
        "/reservas",
        json={
            "id_socio": socio,
            "id_cancha": cancha,
            "fecha_hora_inicio": futuro(hora=hora_inicio),
            "fecha_hora_fin": futuro(hora=hora_fin),
        },
    )

    assert respuesta.status_code == 201
    assert respuesta.get_json()["precio_total"] == total_esperado


def test_cambiar_el_precio_no_altera_el_importe_de_reservas_existentes(
    cliente, socio, cancha, futuro
):
    """La reserva conserva la tarifa vigente al crearse."""
    creada = cliente.post(
        "/reservas",
        json={
            "id_socio": socio,
            "id_cancha": cancha,
            "fecha_hora_inicio": futuro(hora="18:00"),
            "fecha_hora_fin": futuro(hora="20:00"),
        },
    ).get_json()

    cliente.patch(f"/canchas/{cancha}", json={"precio_hora": 1200000})

    consultada = cliente.get(f"/reservas/{creada['id']}").get_json()
    assert consultada["precio_hora"] == 1000000
    assert consultada["precio_total"] == 2000000


def test_una_reserva_nueva_usa_el_precio_vigente_actualizado(
    cliente, socio, cancha, futuro
):
    cliente.patch(f"/canchas/{cancha}", json={"precio_hora": 1200000})

    respuesta = cliente.post(
        "/reservas",
        json={
            "id_socio": socio,
            "id_cancha": cancha,
            "fecha_hora_inicio": futuro(10, hora="09:00"),
            "fecha_hora_fin": futuro(10, hora="10:00"),
        },
    )

    assert respuesta.get_json()["precio_total"] == 1200000


def test_el_cliente_no_puede_fijar_estado_ni_importes(cliente, socio, cancha, futuro):
    """El cliente no puede fijar estado, tarifas, totales ni ids generados."""
    respuesta = cliente.post(
        "/reservas",
        json={
            "id_socio": socio,
            "id_cancha": cancha,
            "fecha_hora_inicio": futuro(hora="18:00"),
            "fecha_hora_fin": futuro(hora="20:00"),
            "estado": "cancelada",
            "precio_hora": 1,
            "precio_total": 1,
            "id": 99,
        },
    )

    assert respuesta.status_code == 400
    assert "estado" in respuesta.get_json()["errors"][0]["description"]


def test_reserva_rechaza_campos_obligatorios_ausentes(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00")},
    )

    assert respuesta.status_code == 400
    assert "fecha_hora_fin" in respuesta.get_json()["errors"][0]["description"]


def test_reserva_con_socio_inexistente_devuelve_404(cliente, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": 9999, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 404


def test_reserva_con_cancha_inexistente_devuelve_404(cliente, socio, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": 9999,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 404


def test_reserva_con_socio_inactivo_devuelve_409(cliente, socio, cancha, futuro):
    cliente.patch(f"/socios/{socio}", json={"activo": False})

    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 409


def test_reserva_con_cancha_inactiva_devuelve_409(cliente, socio, cancha, futuro):
    cliente.patch(f"/canchas/{cancha}", json={"activa": False})

    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 409


def test_una_validacion_fallida_no_guarda_registros(cliente, socio, cancha, futuro):
    cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="19:30")},
    )

    listado = cliente.get("/reservas").get_json()
    assert listado["reservas"] == []


def test_rechaza_reserva_pasada(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={
            "id_socio": socio,
            "id_cancha": cancha,
            "fecha_hora_inicio": futuro(-30, hora="10:00"),
            "fecha_hora_fin": futuro(-30, hora="11:00"),
        },
    )

    assert respuesta.status_code == 400
    assert "pasados" in respuesta.get_json()["errors"][0]["message"]


def test_rechaza_horario_fuera_del_club_por_arriba(cliente, socio, cancha, futuro):
    """El club cierra a las 23:00."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="22:00"),
              "fecha_hora_fin": futuro(hora="23:30")},
    )

    assert respuesta.status_code == 400


def test_rechaza_horario_fuera_del_club_por_abajo(cliente, socio, cancha, futuro):
    """El club abre a las 08:00."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="07:00"),
              "fecha_hora_fin": futuro(hora="09:00")},
    )

    assert respuesta.status_code == 400


def test_rechaza_hora_no_en_punto(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:30"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 400


def test_rechaza_duracion_de_cuatro_horas(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="08:00"),
              "fecha_hora_fin": futuro(hora="12:00")},
    )

    assert respuesta.status_code == 400


def test_rechaza_duracion_de_una_media_hora(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="19:30")},
    )

    assert respuesta.status_code == 400


def test_rechaza_intervalo_que_atraviesa_la_medianoche(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="22:00"),
              "fecha_hora_fin": futuro(1, hora="02:00")},
    )

    assert respuesta.status_code == 400


def test_rechaza_inicio_posterior_al_fin(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="20:00"),
              "fecha_hora_fin": futuro(hora="18:00")},
    )

    assert respuesta.status_code == 400


def test_rechaza_formato_de_fecha_incorrecto(cliente, socio, cancha, futuro):
    """El formato exigido es ISO 8601 con offset fijo -03:00 y 6 decimales."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": "2030-01-01T18:00:00",
              "fecha_hora_fin": "2030-01-01T20:00:00"},
    )

    assert respuesta.status_code == 400


def test_rechaza_desplazamiento_distinto_de_gmt3(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00")[:-6] + "+00:00",
              "fecha_hora_fin": futuro(hora="20:00")[:-6] + "+00:00"},
    )

    assert respuesta.status_code == 400
    assert "GMT-3" in respuesta.get_json()["errors"][0]["description"]


@pytest.fixture
def reserva_18_a_20(cliente, socio, cancha, futuro):
    """Reserva base de 18:00 a 20:00, usada como referencia de superposicion."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )
    assert respuesta.status_code == 201
    return respuesta.get_json()


def test_rechaza_superposicion_parcial(cliente, socio, cancha, futuro, reserva_18_a_20):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="19:00"),
              "fecha_hora_fin": futuro(hora="21:00")},
    )

    assert respuesta.status_code == 409
    assert respuesta.get_json()["errors"][0]["code"] == "ERROR_SUPERPOSICION"


def test_rechaza_intervalo_identico(cliente, socio, cancha, futuro, reserva_18_a_20):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 409


def test_rechaza_intervalo_contenido(cliente, socio, cancha, futuro, reserva_18_a_20):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="19:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 409


def test_rechaza_intervalo_que_contiene_al_otro(cliente, socio, cancha, futuro,
                                                reserva_18_a_20):
    """19:00-20:00 dura menos de una hora, asi que se containmenta con 18:00-21:00."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="21:00")},
    )

    assert respuesta.status_code == 409


def test_acepta_reservas_consecutivas(cliente, socio, cancha, futuro, reserva_18_a_20):
    """Con 18:00-20:00 ocupado si se puede reservar 20:00-21:00."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="20:00"),
              "fecha_hora_fin": futuro(hora="21:00")},
    )

    assert respuesta.status_code == 201


def test_una_reserva_cancelada_libera_el_horario(cliente, socio, cancha, futuro,
                                                 reserva_18_a_20):
    """La cancelacion libera el horario para volver a reservarlo."""
    cancelacion = cliente.put(
        f"/reservas/{reserva_18_a_20['id']}/estado", json={"estado": "cancelada"}
    )
    assert cancelacion.status_code == 200

    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 201


def test_rechaza_superposicion_del_socio_en_otra_cancha(
    cliente, socio, socio_otro, cancha, cancha_otra, futuro, reserva_18_a_20
):
    """Un socio no puede superponerse consigo mismo aunque sea en otra cancha."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha_otra,
              "fecha_hora_inicio": futuro(hora="19:00"),
              "fecha_hora_fin": futuro(hora="20:00")},
    )

    assert respuesta.status_code == 409


def test_acepta_reservas_consecutivas_del_socio(
    cliente, socio, cancha, cancha_otra, futuro, reserva_18_a_20
):
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha_otra,
              "fecha_hora_inicio": futuro(hora="20:00"),
              "fecha_hora_fin": futuro(hora="21:00")},
    )

    assert respuesta.status_code == 201


def test_dos_socios_distintos_pueden_reservar_la_misma_cancha(
    cliente, socio, socio_otro, cancha, futuro, reserva_18_a_20
):
    """La superposicion se evalua por recurso, no por socio."""
    respuesta = cliente.post(
        "/reservas",
        json={"id_socio": socio_otro, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="10:00"),
              "fecha_hora_fin": futuro(hora="11:00")},
    )

    assert respuesta.status_code == 201


def test_cancelar_una_reserva_devuelve_200_con_la_reserva(
    cliente, socio, cancha, futuro, reserva_18_a_20
):
    respuesta = cliente.put(
        f"/reservas/{reserva_18_a_20['id']}/estado", json={"estado": "cancelada"}
    )

    assert respuesta.status_code == 200
    assert respuesta.get_json()["estado"] == "cancelada"


def test_repetir_el_estado_actual_devuelve_exito_sin_modificar(
    cliente, socio, cancha, futuro, reserva_18_a_20
):
    """Repetir el estado actual devuelve exito y no cambia la reserva."""
    respuesta = cliente.put(
        f"/reservas/{reserva_18_a_20['id']}/estado", json={"estado": "confirmada"}
    )

    assert respuesta.status_code == 200
    assert respuesta.get_json()["estado"] == "confirmada"


def test_repetir_el_estado_sobre_una_cancelada_devuelve_exito(
    cliente, socio, cancha, futuro, reserva_18_a_20
):
    id_reserva = reserva_18_a_20["id"]
    cliente.put(f"/reservas/{id_reserva}/estado", json={"estado": "cancelada"})

    respuesta = cliente.put(f"/reservas/{id_reserva}/estado", json={"estado": "cancelada"})

    assert respuesta.status_code == 200
    assert respuesta.get_json()["estado"] == "cancelada"


def test_cancelar_una_reserva_ya_cancelada_no_se_permite_reabrir(
    cliente, socio, cancha, futuro, reserva_18_a_20
):
    """'cancelada' es un estado terminal: no se puede volver a 'confirmada'."""
    id_reserva = reserva_18_a_20["id"]
    cliente.put(f"/reservas/{id_reserva}/estado", json={"estado": "cancelada"})

    respuesta = cliente.put(f"/reservas/{id_reserva}/estado", json={"estado": "confirmada"})

    assert respuesta.status_code == 409


def test_finalizar_una_reserva_que_ya_termino(cliente, socio, cancha, ayer,
                                             reservar_directamente):
    """Una reserva de ayer ya empezo, asi que el resultado no depende de la hora."""
    from datetime import timedelta

    inicio = ayer
    fin = ayer + timedelta(hours=1)
    id_reserva = reservar_directamente(socio, cancha, inicio, fin)

    respuesta = cliente.put(
        f"/reservas/{id_reserva}/estado", json={"estado": "finalizada"}
    )

    assert respuesta.status_code == 200
    assert respuesta.get_json()["estado"] == "finalizada"


def test_finalizar_una_reserva_que_aun_no_termina_devuelve_409(
    cliente, socio, cancha, futuro, reserva_18_a_20
):
    respuesta = cliente.put(
        f"/reservas/{reserva_18_a_20['id']}/estado", json={"estado": "finalizada"}
    )

    assert respuesta.status_code == 409


def test_cancelar_una_reserva_ya_iniciada_devuelve_409(
    cliente, socio, cancha, ayer, reservar_directamente
):
    """La cancelacion solo existe antes del inicio, y el de ayer ya paso."""
    from datetime import timedelta

    id_reserva = reservar_directamente(
        socio, cancha, ayer, ayer + timedelta(hours=1)
    )

    respuesta = cliente.put(
        f"/reservas/{id_reserva}/estado", json={"estado": "cancelada"}
    )

    assert respuesta.status_code == 409


def test_estado_desconocido_produce_400(cliente, socio, cancha, futuro,
                                        reserva_18_a_20):
    respuesta = cliente.put(
        f"/reservas/{reserva_18_a_20['id']}/estado", json={"estado": "pendiente"}
    )

    assert respuesta.status_code == 400


def test_cambiar_estado_de_reserva_inexistente_devuelve_404(cliente):
    respuesta = cliente.put("/reservas/9999/estado", json={"estado": "cancelada"})

    assert respuesta.status_code == 404


def test_transicion_desde_finalizada_no_se_permite(cliente, socio, cancha, ayer,
                                                   reservar_directamente):
    """Una reserva finalizada es un estado terminal."""
    from datetime import timedelta

    id_reserva = reservar_directamente(
        socio, cancha, ayer, ayer + timedelta(hours=1), estado="finalizada"
    )

    respuesta = cliente.put(
        f"/reservas/{id_reserva}/estado", json={"estado": "cancelada"}
    )

    assert respuesta.status_code == 409


def test_obtener_reserva_inexistente_devuelve_404(cliente):
    assert cliente.get("/reservas/9999").status_code == 404


def test_se_pueden_consultar_reservas_pasadas(cliente, socio, cancha, futuro,
                                               reserva_18_a_20):
    respuesta = cliente.get("/reservas")

    assert respuesta.status_code == 200
    assert [r["id"] for r in respuesta.get_json()["reservas"]] == [reserva_18_a_20["id"]]


def test_filtrar_reservas_por_cancha(cliente, socio, cancha, cancha_otra, futuro,
                                     reserva_18_a_20):
    otra = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha_otra,
              "fecha_hora_inicio": futuro(hora="09:00"),
              "fecha_hora_fin": futuro(hora="10:00")},
    ).get_json()

    resultado = cliente.get(f"/reservas?id_cancha={cancha_otra}").get_json()["reservas"]

    assert [r["id"] for r in resultado] == [otra["id"]]


def test_filtrar_reservas_por_socio(cliente, socio, socio_otro, cancha, cancha_otra,
                                    futuro, reserva_18_a_20):
    otra = cliente.post(
        "/reservas",
        json={"id_socio": socio_otro, "id_cancha": cancha_otra,
              "fecha_hora_inicio": futuro(hora="09:00"),
              "fecha_hora_fin": futuro(hora="10:00")},
    ).get_json()

    resultado = cliente.get(f"/reservas?id_socio={socio_otro}").get_json()["reservas"]

    assert [r["id"] for r in resultado] == [otra["id"]]


def test_filtrar_reservas_por_estado(cliente, socio, cancha, futuro,
                                     reserva_18_a_20):
    cliente.put(f"/reservas/{reserva_18_a_20['id']}/estado", json={"estado": "cancelada"})

    confirmadas = cliente.get("/reservas?estado=confirmada").get_json()["reservas"]
    canceladas = cliente.get("/reservas?estado=cancelada").get_json()["reservas"]

    assert confirmadas == []
    assert [r["id"] for r in canceladas] == [reserva_18_a_20["id"]]


def test_filtrar_reservas_por_estado_desconocido_produce_400(cliente):
    assert cliente.get("/reservas?estado=pendiente").status_code == 400


def test_filtrar_reservas_por_rango_de_fechas_inclusivo(cliente, socio, cancha,
                                                         cancha_otra, futuro):
    """El rango se aplica al dia de utilizacion e incluye ambos extremos."""
    dia_10 = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(10, hora="09:00"),
              "fecha_hora_fin": futuro(10, hora="10:00")},
    ).get_json()
    dia_20 = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha_otra,
              "fecha_hora_inicio": futuro(20, hora="09:00"),
              "fecha_hora_fin": futuro(20, hora="10:00")},
    ).get_json()

    from datetime import date, timedelta

    hoy = date.today()
    desde = (hoy + timedelta(days=10)).isoformat()
    hasta = (hoy + timedelta(days=20)).isoformat()

    resultado = cliente.get(
        f"/reservas?fecha_desde={desde}&fecha_hasta={hasta}"
    ).get_json()["reservas"]

    assert {r["id"] for r in resultado} == {dia_10["id"], dia_20["id"]}


def test_filtrar_reservas_acepta_un_solo_extremo(cliente, socio, cancha, futuro,
                                                  reserva_18_a_20):
    from datetime import date, timedelta

    desde = (date.today() + timedelta(days=30)).isoformat()

    resultado = cliente.get(f"/reservas?fecha_desde={desde}").get_json()["reservas"]

    assert [r["id"] for r in resultado] == [reserva_18_a_20["id"]]


def test_filtrar_reservas_rechaza_rango_invertido(cliente, fecha_futura):
    """Si se envian ambos extremos, fecha_desde debe ser <= fecha_hasta."""
    respuesta = cliente.get(
        f"/reservas?fecha_desde={fecha_futura(20)}&fecha_hasta={fecha_futura(10)}"
    )

    assert respuesta.status_code == 400


def test_no_se_puede_eliminar_una_cancha_con_reservas(cliente, socio, cancha,
                                                      futuro, reserva_18_a_20):
    respuesta = cliente.delete(f"/canchas/{cancha}")

    assert respuesta.status_code == 409


def test_no_se_puede_eliminar_una_cancha_con_una_reserva_cancelada(
    cliente, socio, cancha, futuro, reserva_18_a_20
):
    """Una reserva cancelada tambien impide la baja: el historial no se pierde."""
    cliente.put(f"/reservas/{reserva_18_a_20['id']}/estado", json={"estado": "cancelada"})

    respuesta = cliente.delete(f"/canchas/{cancha}")

    assert respuesta.status_code == 409


def test_la_alternativa_a_eliminar_es_desactivar(cliente, socio, cancha, futuro,
                                                 reserva_18_a_20):
    desactivada = cliente.patch(f"/canchas/{cancha}", json={"activa": False})
    assert desactivada.status_code == 200

    nueva = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="09:00"),
              "fecha_hora_fin": futuro(hora="10:00")},
    )
    assert nueva.status_code == 409
