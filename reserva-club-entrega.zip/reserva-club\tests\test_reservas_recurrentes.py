"""Pruebas de las reservas recurrentes (extension opcional).

La seccion 10 del enunciado exige atomicidad: si una fecha de la serie esta
ocupada, no se guarda ninguna reserva.
"""

# El fixture `futuro` cuenta desde hoy, asi que las semanas siguientes se piden
# como DIA_BASE + 7, DIA_BASE + 14, etc.
DIA_BASE = 10


def test_crear_serie_devuelve_201_con_todas_las_reservas(
    cliente, socio, cancha, futuro
):
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 201
    reservas = respuesta.get_json()["reservas"]
    assert len(reservas) == 4
    assert all(r["estado"] == "confirmada" for r in reservas)


def test_las_reservas_de_la_serie_caen_siete_dias_por_paso(cliente, socio, cancha,
                                                            futuro):
    """Cada reserva cae el mismo dia de la semana y a la misma hora."""
    cuerpo = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE, hora="20:00"),
              "cantidad_semanas": 3},
    ).get_json()

    inicios = [r["fecha_hora_inicio"] for r in cuerpo["reservas"]]

    assert inicios[0].startswith(futuro(DIA_BASE, hora="18:00")[:10])
    assert inicios[1].startswith(futuro(DIA_BASE + 7, hora="18:00")[:10])
    assert inicios[2].startswith(futuro(DIA_BASE + 14, hora="18:00")[:10])


def test_la_serie_respeta_el_precio_de_la_cancha(cliente, socio, cancha, futuro):
    cuerpo = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 3},
    ).get_json()

    for reserva in cuerpo["reservas"]:
        assert reserva["precio_hora"] == 1000000
        assert reserva["precio_total"] == 2000000


def test_la_serie_queda_registrada_en_el_listado_de_reservas(cliente, socio, cancha,
                                                            futuro):
    cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 3},
    )

    listado = cliente.get(f"/reservas?id_cancha={cancha}").get_json()["reservas"]

    assert len(listado) == 3


def test_si_una_fecha_esta_ocupada_no_se_guarda_ninguna(cliente, socio, cancha,
                                                        futuro):
    """Se ocupa la segunda semana de una serie de cuatro: 409 y nada guardado."""
    # Se reserva manualmente la segunda semana de la serie.
    cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE + 7, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE + 7, hora="20:00")},
    )

    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE, hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 409
    # Queda solo la reserva creada a mano.
    listado = cliente.get(f"/reservas?id_cancha={cancha}").get_json()["reservas"]
    assert len(listado) == 1


def test_el_409_informa_las_fechas_en_conflicto(cliente, socio, cancha, futuro):
    cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE + 7, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE + 7, hora="20:00")},
    )

    cuerpo = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE, hora="20:00"),
              "cantidad_semanas": 4},
    ).get_json()

    conflictos = cuerpo["conflictos"]
    assert len(conflictos) == 1
    assert conflictos[0] == futuro(DIA_BASE + 7)[:10]


def test_el_409_ignora_las_reservas_canceladas(cliente, socio, cancha, futuro):
    """Una reserva cancelada libera la franja, asi que la serie si puede crearse."""
    existente = cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE + 7, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE + 7, hora="20:00")},
    ).get_json()
    cliente.put(f"/reservas/{existente['id']}/estado", json={"estado": "cancelada"})

    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE, hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 201


def test_el_409_tambien_detecta_el_conflicto_por_socio(cliente, socio, socio_otro,
                                                       cancha, cancha_otra,
                                                       futuro):
    """El socio tampoco puede superponerse consigo mismo en otra cancha."""
    cliente.post(
        "/reservas",
        json={"id_socio": socio, "id_cancha": cancha_otra,
              "fecha_hora_inicio": futuro(DIA_BASE + 7, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE + 7, hora="20:00")},
    )

    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE, hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 409


def test_el_409_tambien_detecta_el_bloqueo_de_mantenimiento(cliente, socio, cancha,
                                                            futuro):
    """Un bloqueo de mantenimiento tambien impide crear la serie."""
    respuesta_bloqueo = cliente.post(
        "/bloqueos",
        json={"id_cancha": cancha, "fecha": futuro(DIA_BASE + 14)[:10],
              "hora_inicio": "18:00:00", "hora_fin": "20:00:00", "motivo": "Pintura"},
    )
    assert respuesta_bloqueo.status_code == 201

    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(DIA_BASE, hora="18:00"),
              "fecha_hora_fin": futuro(DIA_BASE, hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 409


def test_cantidad_de_semanas_fuera_de_rango_produce_400(cliente, socio, cancha,
                                                         futuro):
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 20},
    )

    assert respuesta.status_code == 400


def test_cantidad_de_semanas_no_entera_produce_400(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": "cuatro"},
    )

    assert respuesta.status_code == 400


def test_serie_de_una_sola_semana_produce_400(cliente, socio, cancha, futuro):
    """La cantidad incluye la primera, asi que el minimo es 2."""
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 1},
    )

    assert respuesta.status_code == 400


def test_serie_valida_las_horas_con_las_mismas_reglas(cliente, socio, cancha,
                                                       futuro):
    """Una duracion de cuatro horas esta prohibida tambien en una serie."""
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="22:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 400


def test_serie_con_horas_no_en_punto_produce_400(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:30"),
              "fecha_hora_fin": futuro(hora="20:30"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 400


def test_serie_que_arranca_en_el_pasado_produce_400(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(-14, hora="18:00"),
              "fecha_hora_fin": futuro(-14, hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 400


def test_serie_con_socio_inexistente_produce_404(cliente, cancha, futuro):
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": 9999, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 404


def test_serie_con_socio_inactivo_produce_409(cliente, socio, cancha, futuro):
    cliente.patch(f"/socios/{socio}", json={"activo": False})

    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 409


def test_serie_con_cancha_inactiva_produce_409(cliente, socio, cancha, futuro):
    cliente.patch(f"/canchas/{cancha}", json={"activa": False})

    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 4},
    )

    assert respuesta.status_code == 409


def test_serie_con_campos_desconocidos_produce_400(cliente, socio, cancha, futuro):
    respuesta = cliente.post(
        "/reservas/recurrentes",
        json={"id_socio": socio, "id_cancha": cancha,
              "fecha_hora_inicio": futuro(hora="18:00"),
              "fecha_hora_fin": futuro(hora="20:00"),
              "cantidad_semanas": 4, "descuento": 50},
    )

    assert respuesta.status_code == 400


def test_serie_sin_campos_obligatorios_produce_400(cliente, socio, cancha):
    respuesta = cliente.post(
        "/reservas/recurrentes", json={"id_socio": socio, "id_cancha": cancha}
    )

    assert respuesta.status_code == 400
