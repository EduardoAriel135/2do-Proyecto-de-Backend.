"""Pruebas de socios: alta, correo, unicidad y actualizacion."""


def test_crear_socio_devuelve_201_y_activo_por_defecto(cliente):
    respuesta = cliente.post(
        "/socios", json={"nombre": "Ana Gomez", "email": "ana@example.com"}
    )

    assert respuesta.status_code == 201
    socio = respuesta.get_json()
    assert socio["id"] >= 1
    assert socio["nombre"] == "Ana Gomez"
    assert socio["email"] == "ana@example.com"
    # El servidor asigna activo, el cliente no.
    assert socio["activo"] is True


def test_crear_socio_normaliza_el_correo(cliente):
    """El correo se guarda en minusculas y sin espacios en los extremos."""
    respuesta = cliente.post(
        "/socios", json={"nombre": "Ana", "email": "  ANA.Gomez@EXAMPLE.com  "}
    )

    assert respuesta.status_code == 201
    assert respuesta.get_json()["email"] == "ana.gomez@example.com"


def test_crear_socio_rechaza_nombre_vacio_de_espacios(cliente):
    respuesta = cliente.post(
        "/socios", json={"nombre": "   ", "email": "ana@example.com"}
    )

    assert respuesta.status_code == 400
    assert respuesta.get_json()["errors"][0]["code"] == "ERROR_VALIDACION"


def test_crear_socio_rechaza_correo_invalido(cliente):
    respuesta = cliente.post("/socios", json={"nombre": "Ana", "email": "no-es-mail"})

    assert respuesta.status_code == 400


def test_crear_socio_rechaza_campos_desconocidos(cliente):
    """El cliente no puede mandar activo, id ni ningun otro campo no previsto."""
    respuesta = cliente.post(
        "/socios",
        json={"nombre": "Ana", "email": "ana@example.com", "activo": False, "id": 99},
    )

    assert respuesta.status_code == 400
    assert "activo" in respuesta.get_json()["errors"][0]["description"]


def test_crear_socio_rechaza_campos_obligatorios_ausentes(cliente):
    respuesta = cliente.post("/socios", json={"nombre": "Ana"})

    assert respuesta.status_code == 400
    assert "email" in respuesta.get_json()["errors"][0]["description"]


def test_crear_socio_rechaza_cuerpo_vacio(cliente):
    respuesta = cliente.post("/socios", json={})

    assert respuesta.status_code == 400


def test_correo_duplicado_produce_409(cliente, socio):
    respuesta = cliente.post(
        "/socios", json={"nombre": "Otro", "email": "ana@example.com"}
    )

    assert respuesta.status_code == 409
    assert respuesta.get_json()["errors"][0]["code"] == "ERROR_CONFLICTO"


def test_correo_duplicado_produce_409_tambien_si_el_socio_existente_esta_inactivo(
    cliente, socio
):
    """El correo es unico en todo el club, tambien entre los inactivos."""
    desactivado = cliente.patch(f"/socios/{socio}", json={"activo": False})
    assert desactivado.status_code == 200

    respuesta = cliente.post(
        "/socios", json={"nombre": "Otro", "email": "ana@example.com"}
    )

    assert respuesta.status_code == 409


def test_obtener_socio_inexistente_devuelve_404(cliente):
    respuesta = cliente.get("/socios/9999")

    assert respuesta.status_code == 404
    assert respuesta.get_json()["errors"][0]["code"] == "ERROR_NO_ENCONTRADO"


def test_actualizar_socio_devuelve_200_con_el_recurso_actualizado(cliente, socio):
    respuesta = cliente.patch(f"/socios/{socio}", json={"nombre": "Ana Gomez Lopez"})

    assert respuesta.status_code == 200
    assert respuesta.get_json()["nombre"] == "Ana Gomez Lopez"


def test_actualizar_socio_conserva_los_campos_omitidos(cliente, socio):
    respuesta = cliente.patch(f"/socios/{socio}", json={"nombre": "Ana Gomez Lopez"})

    actualizado = respuesta.get_json()
    assert actualizado["email"] == "ana@example.com"
    assert actualizado["activo"] is True


def test_actualizar_socio_rechaza_email_ya_usado_por_otro(cliente, socio, socio_otro):
    respuesta = cliente.patch(
        f"/socios/{socio}", json={"email": "bruno@example.com"}
    )

    assert respuesta.status_code == 409


def test_actualizar_socio_admite_reenviar_su_propio_email(cliente, socio):
    """Repetir el propio correo no es un conflicto."""
    respuesta = cliente.patch(
        f"/socios/{socio}", json={"email": "ANA@example.com"}
    )

    assert respuesta.status_code == 200
    assert respuesta.get_json()["email"] == "ana@example.com"


def test_actualizar_socio_rechaza_cuerpo_vacio(cliente, socio):
    respuesta = cliente.patch(f"/socios/{socio}", json={})

    assert respuesta.status_code == 400


def test_actualizar_socio_inexistente_devuelve_404(cliente):
    respuesta = cliente.patch("/socios/9999", json={"nombre": "Fantasma"})

    assert respuesta.status_code == 404


def test_actualizar_socio_rechaza_activo_no_booleano(cliente, socio):
    respuesta = cliente.patch(f"/socios/{socio}", json={"activo": "si"})

    assert respuesta.status_code == 400


def test_listar_socios_por_defecto_trae_activos_e_inactivos(cliente, socio):
    inactivo = cliente.post("/socios", json={"nombre": "B", "email": "b@example.com"})
    id_inactivo = inactivo.get_json()["id"]
    cliente.patch(f"/socios/{id_inactivo}", json={"activo": False})

    respuesta = cliente.get("/socios")
    ids = [socio["id"] for socio in respuesta.get_json()["socios"]]

    assert respuesta.status_code == 200
    assert socio in ids
    assert id_inactivo in ids


def test_filtrar_socios_por_activo(cliente, socio):
    inactivo = cliente.post("/socios", json={"nombre": "B", "email": "b@example.com"})
    id_inactivo = inactivo.get_json()["id"]
    cliente.patch(f"/socios/{id_inactivo}", json={"activo": False})

    activos = cliente.get("/socios?activo=true").get_json()["socios"]
    inactivos = cliente.get("/socios?activo=false").get_json()["socios"]

    assert [s["id"] for s in activos] == [socio]
    assert [s["id"] for s in inactivos] == [id_inactivo]


def test_filtrar_socios_por_nombre_parcial_e_insensible(cliente, socio):
    respuesta = cliente.get("/socios?nombre=ana")

    assert respuesta.status_code == 200
    assert [s["id"] for s in respuesta.get_json()["socios"]] == [socio]


def test_filtrar_socios_rechaza_booleano_invalido(cliente):
    """Los filtros booleanos admiten unicamente true o false."""
    respuesta = cliente.get("/socios?activo=1")

    assert respuesta.status_code == 400
